#include <stdio.h>
#include <string.h>

int main()
{
    char frase[60], *p = &frase[0];

    printf("Digite uma frase: ");
    scanf("%[^\n]", frase);
    
    int size = strlen(frase);
    for(int i=0; i<size; i++){
        if(*(p+i) == ' ') printf("\n");
        else printf("%c", *(p+i));
    }

    return 0;
}