#include <stdio.h>

int main()
{
    char frase[60], *p = &frase[0];
    int i = 0, cont = 0;

    printf("Digite uma frase: ");
    scanf("%[^\n]", frase);
    while(*(p+i)!='\0'){
        i++;
        if(*(p+i) != ' ') cont++;
    } 
    printf("A frase possui %d caracteres (com espaco)\nA frase possui %d caracteres (sem espaco)\n", i, cont);

    return 0;
}