#include <stdio.h>

int main()
{
    int v[5], *p = &v[0];

    for(int i=0; i<5; i++){
        printf("Digite %d.o valor: ", i+1);
        scanf("%d", &v[i]);
    }
    printf("DOBRO\n");
    for(int i=0; i<5; i++){
        printf("%d.o valor: %d\n", i+1, *(p+i)*2);
    }

    return 0;
}