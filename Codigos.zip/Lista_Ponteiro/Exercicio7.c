#include <stdio.h>

int main()
{
    int a, *b = &a, **c = &b, ***d = &c;

    printf("Digite um valor: ");
    scanf("%d", &a);
    printf("Valor: %d\nDobro: %d\nTriplo: %d\nQuadruplo: %d\n", a, *b*2, **c*3, ***d*4);

    return 0;
}