#include <stdio.h>

int main()
{
    float m[3][3], *p = &m[0][0];

    for(int i=0; i<9; i++){
        printf("%d\n", (p+i));
    }

    return 0;
}