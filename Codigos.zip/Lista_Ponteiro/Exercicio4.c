#include <stdio.h>
#include <string.h>

int String(char a[], char b[]);

int main()
{
    char a[20], b[20], teste;

    printf("Digite duas palavras: ");
    scanf(" %s %s", a, b);
    teste = String(a, b);
    if(teste==1) printf("%s esta contido em %s\n", b, a);
    else printf("%s nao esta contido em %s\n", b, a);

    return 0;
}
int String(char a[], char b[]){
    char *p;
    p = strstr(a, b);
    if(p!=NULL) return 1;
    else return 0;
}