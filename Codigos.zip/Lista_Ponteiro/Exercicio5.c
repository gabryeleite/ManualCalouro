#include <stdio.h>

void Array(int *p, int valor, int N);
void Print(int *p, int N);

int main()
{
    int N, valor;

    printf("Digite tamanho do vetor: ");
    scanf("%d", &N);
    int v[N];
    printf("Digite um valor: ");
    scanf("%d", &valor);
    Array(v, valor, N);
    Print(v, N);

    return 0;
}
void Array(int *p, int valor, int N){
    for(int i=0; i<N; i++){
        *(p+i) = valor;
    }
}
void Print(int *p, int N){
    for(int i=0; i<N; i++) printf("%d\n", *(p+i));
}