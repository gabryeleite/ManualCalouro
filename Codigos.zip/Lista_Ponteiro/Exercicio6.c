#include <stdio.h>

void Print(int *p, int N);

int main()
{
    int N;

    printf("Digite tamanho do vetor: ");
    scanf("%d", &N);
    int v[N];

    for(int i=0; i<N; i++){
        printf("Digite o %d.o valor: ", i+1);
        scanf("%d", &v[i]);
    }
    Print(v, N);

    return 0;
}
void Print(int *p, int N){
    for(int i=0; i<N; i++) printf("%d\n", *(p+i));
}