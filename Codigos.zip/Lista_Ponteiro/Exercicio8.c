#include <stdio.h>

void MinMax(int *pv, int *pmin, int *pmax, int N);

int main()
{
    int N, min, max;

    printf("Digite tamanho do vetor: ");
    scanf("%d", &N);
    int v[N];

    for(int i=0; i<N; i++){
        printf("Digite o %d.o valor: ", i+1);
        scanf("%d", &v[i]);
    }
    MinMax(v, &min, &max, N-1);
    printf("Valor minimo: %d\nValor maximo: %d\n", min, max);

    return 0;
}
void MinMax(int *pv, int *pmin, int *pmax, int N){
    *pmax = *pv;
    *pmin = *pv;
    for(int i=0; i<N; i++){
        if(*(pv+i)>*pmax) *pmax = *(pv+i);
        if(*(pv+i)<*pmin) *pmin = *(pv+i);
    }
}