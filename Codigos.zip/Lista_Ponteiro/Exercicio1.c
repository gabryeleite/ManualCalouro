#include <stdio.h>

int main()
{
    int a, b, *pa = &a, *pb = &b;

    printf("Digite dois valores: ");
    scanf("%d%d", &a, &b);
    printf("Endereco de a: %d\nEndereco de b: %d\n", pa, pb);
    if(pa>pb) printf("Valor do maior endereco: %d\n", *pa);
    else if(pb>pa) printf("Valor do maior endereco: %d\n", *pb);

    return 0;
}