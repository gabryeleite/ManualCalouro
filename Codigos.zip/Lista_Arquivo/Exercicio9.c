#include <stdio.h>
#include <stdlib.h>

int Menu();
void Gerenciar(char txt[]);

int main()
{
    char file[40] = "9Turma.txt";
    Gerenciar(file);

    return 0;
}
int Menu(){
    int N;
    printf("[1]Definir informacoes da turma\n[2]Inserir aluno e notas\n[3]Exibir alunos e medias\n[4]Exibir alunos aprovados\n[5]Exibir alunos reprovados\n[6]Salvar dados em Disco\n[7]Sair do programa\nEscolha: ");
    scanf("%d", &N);
    return N;
}
void Gerenciar(char txt[]){
    FILE *file = fopen(txt,"a+");
    if(file==NULL) printf("Erro ao abrir o arquivo!\n");
    else{
        char nome[40], op;
        float nota1, nota2, media=0;
        while((op=Menu())!=7){
            if(op==1){
                int quant=0;
                rewind(file);
                while(!feof(file)){
                    fscanf(file,"%*s %f %f", &nota1, &nota2);
                    media += (nota1+nota2)/2.0;
                    quant++;
                }
                printf("Quantidade de alunos da turma: %.d\nMedia da turma: %.2f\n", quant, media/quant);
                media = 0;
            }else if(op==2){
                printf("Digite nome do aluno: ");
                scanf("%s", nome);
                printf("Digite duas notas: ");
                scanf("%f%f", &nota1, &nota2);
                fprintf(file,"\n%s %.2f %.2f", nome, nota1, nota2);
                printf("Aluno e notas adicionados com sucesso!\n");
            }else if(op==3){
                rewind(file);
                while(!feof(file)){
                    fscanf(file,"%s %f %f", nome, &nota1, &nota2);
                    media = (nota1+nota2)/2.0;
                    printf("Aluno: %s\tMedia: %.2f\n", nome, media);
                }
            }else if(op==4){
                rewind(file);
                printf("APROVADOS: \n");
                while(!feof(file)){
                    fscanf(file,"%s %f %f", nome, &nota1, &nota2);
                    media = (nota1+nota2)/2.0;
                    if(media>=6) printf("%s\n", nome);
                }
            }else if(op==5){
                rewind(file);
                printf("REPROVADOS: \n");
                while(!feof(file)){
                    fscanf(file,"%s %f %f", nome, &nota1, &nota2);
                    media = (nota1+nota2)/2.0;
                    if(media<6) printf("%s\n", nome);
                }
            }else if(op==6){
                printf("Dados salvos no Disco!\n");
            }else printf("Comando nao existente!\nTente novamente.\n");
            system("pause");
            system("cls");
        }
        fclose(file);
        printf("Programa finalizado!\n");
    }
}