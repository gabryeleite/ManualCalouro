#include <stdio.h>

int Leitura(char txt[], char letra);

int main()
{
    char file[40] = "5Letra.txt", letra;
    int contagem; 
    printf("Digite uma letra: ");
    scanf("%c", &letra);
    contagem = Leitura(file, letra);
    printf("[%c] aparece %d vez(es) no arquivo texto.\n", letra, contagem);

    return 0;
}
int Leitura(char txt[], char letra){
    int i=0;
    FILE *file = fopen(txt,"r");
    if(file==NULL) printf("Erro ao abrir o arquivo!\n");
    else{
        char letra1;
        while(!feof(file)){
            letra1 = fgetc(file);
            if(letra==letra1) i++;
        }
        fclose(file);
    }
    return i;
}