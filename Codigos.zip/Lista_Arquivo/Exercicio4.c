#include <stdio.h>
#include <stdlib.h>

int** Matriz(char txt[]);
void Print(int **p, int lin, int col);

int main()
{
    char file[40] = "4Matriz.txt";
    int **matriz = Matriz(file);

    for(int i=0; i<3; i++) free(matriz[i]);
    free(matriz);

    return 0;
}
int** Matriz(char txt[]){
    FILE *file = fopen(txt,"r");
    if(file==NULL){
        printf("Erro ao abrir o arquivo!\n");
        return NULL;
    } 
    else{
        int lin, col;
        fscanf(file, "%d %d", &lin, &col);
        int **p = malloc(lin*sizeof(int*));
        for(int i=0; i<lin; i++) p[i] = calloc(col,sizeof(int));
        for(int i=0; i<lin; i++){
            for(int j=0; j<col; j++){
                fscanf(file, "%d", &p[i][j]);
            }
        }
        Print(p, lin, col);
        fclose(file);
        return p;
    }
}
void Print(int **p, int lin, int col){
    printf("Matriz: \n");
    for(int i=0; i<lin; i++){
        for(int j=0; j<col; j++){
            printf("%2d ", p[i][j]);
        }
        printf("\n");
    }
}