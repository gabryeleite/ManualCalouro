#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int** Matriz(int lin, int col);
void Escrita(int **p, int lin, int col);

int main()
{
    int lin, col;
    printf("Digite linha e coluna da matriz: ");
    scanf("%d%d", &lin, &col);
    srand(time(NULL));
    int **matriz = Matriz(lin, col);
    Escrita(matriz, lin, col);
    for(int  i=0; i<lin; i++) free(matriz[i]);
    free(matriz);

    return 0;
}
int** Matriz(int lin, int col){
    int **p = malloc(lin*sizeof(int *));
    if(p==NULL) printf("Erro. Memoria Insuficiente!\n");
    else{
        for(int  i=0; i<lin; i++) p[i] = calloc(col,sizeof(int));
        for(int i=0; i<lin; i++){
            for(int j=0; j<col; j++){
                p[i][j] = rand() % 100; //gera valores aleatorios para a matriz
            }
        }
    }
    return p;
}
void Escrita(int **p, int lin, int col){
    FILE *file = fopen("8Matriz","w");
    if(file==NULL) printf("Erro ao abrir o arquivo!\n");
    else{
        for(int i=0; i<lin; i++){
            for(int j=0; j<col; j++){
                fprintf(file, "%2d ", p[i][j]);
            }
            fprintf(file, "\n");
        }
        printf("Arquivo criado com sucesso!\n");
        fclose(file);
    }
}