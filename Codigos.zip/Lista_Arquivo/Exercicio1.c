#include <stdio.h>

int main() 
{
    int N, binario[32];
    FILE *file = fopen("1Binario.txt", "w");
    if(file==NULL){
        printf("Erro ao abrir o arquivo!\n");
        return 1;
    }
    while(1){
        printf("Digite um numero: ");
        scanf("%d", &N);
        if(N<0) break;
        int i = 0;
        while(N>0){
            binario[i] = N%2;
            N /= 2;
            i++;
        }
        for(int j=i-1; j>=0; j--) fprintf(file, "%d", binario[j]);
        fprintf(file, "\n");
    }
    printf("Arquivo criado com sucesso!\n");
    fclose(file);

    return 0;
}