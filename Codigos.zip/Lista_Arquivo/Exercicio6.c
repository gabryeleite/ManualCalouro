#include <stdio.h>
#include <stdlib.h>

typedef struct{
    char nome[40];
    char esporte[40];
    int idade;
    float altura;
} atleta;

void Escrita(char txt[]);

int main()
{
    char file[40] = "6Atleta.txt";
    Escrita(file);

    return 0;
}
void Escrita(char txt[]){
    FILE *file = fopen(txt,"w");
    if(file==NULL) printf("Erro ao abrir o arquivo!\n");
    else{
        atleta *p = malloc(5*sizeof(atleta));
        for(int i=0; i<5; i++){
            printf("\nATLETA %d\n", i+1);
            printf("Nome: ");
            scanf(" %[^\n]", p[i].nome);
            printf("Esporte: ");
            scanf(" %[^\n]", p[i].esporte);
            printf("Idade: ");
            scanf("%d", &p[i].idade);
            printf("Altura: ");
            scanf("%f", &p[i].altura);
            fprintf(file, "ATLETA %d\nNome: %s\nEsporte: %s\nIdade: %d\nAltura: %.2f\n\n", i+1, p[i].nome, p[i].esporte, p[i].idade, p[i].altura);
        }
        free(p);
        fclose(file);
        printf("\nArquivo criado com sucesso!\n");
    }
}