#include <stdio.h>
#include <stdlib.h>

typedef struct{
    char nome[40];
    char esporte[40];
    int idade;
    float altura;
} atleta;

void Leitura(char txt[]);

int main()
{
    char file[40] = "7Atleta.dat";
    Leitura(file);

    return 0;
}
void Leitura(char txt[]){
    FILE *file = fopen(txt,"rb");
    if(file==NULL) printf("Erro ao abrir o arquivo!\n");
    else{
        atleta *p = malloc(5*sizeof(atleta));
        float alto;
        int velho, varH=0, varI=0;
        for(int i=0; i<5; i++){
            fread(&p[i], sizeof(atleta), 1, file);
            if(i==0){
                alto = p[i].altura;
                velho = p[i].idade;
            }else{
                if(p[i].altura>alto){
                    alto = p[i].altura;
                    varH = i;
                } 
                if(p[i].idade>velho){
                    velho = p[i].idade;
                    varI = i;
                }
            }
            printf("Nome: %s\nEsporte: %s\nIdade: %d\nAltura: %.2f\n", p[i].nome, p[i].esporte, p[i].idade, p[i].altura);
        }
        printf("Atleta mais alto: %s\nAtleta mais velho: %s", p[varH].nome, p[varI].nome);
        free(p);
        fclose(file);
    }
}