#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 50

typedef struct{
    int cod;
    char nome[MAX];
    float valor;
    int mes;
} dados;

int Menu();
void CriarArquivo(char arquivo[]);
int EscreverRegistro(char arquivo[], dados **p, int cont);
int ExcluirRegistro(char arquivo[], dados **p, int cont);
void AlterarValor(char arquivo[], dados **p, int cont);
void ImprimirRegistro(char arquivo[], dados **p, int cont);
void ExcluirArquivo(char arquivo[]);

int main()
{
    int op, cont = 0, size = 50; //Da para armazenar um max de 50 vendedores
    dados *venda[size];
    char file[30] = "10Vendas.dat";

    do{
        op = Menu();
        switch (op){
        case 1:
            CriarArquivo(file);
            break;
        case 2:
            cont += EscreverRegistro(file, venda, cont);
            break;
        case 3:
            cont += ExcluirRegistro(file, venda, cont);
            break;
        case 4:
            AlterarValor(file, venda, cont);
            break;
        case 5:
            ImprimirRegistro(file, venda, cont);
            break;
        case 6:
            ExcluirArquivo(file);
            break;
        case 7:
            printf("Programa finalizado!\n");
            break;
        default:
            printf("Opcao invalida!\nTente novamente.\n");
            break;
        }
    }while(op!=7);

    return 0;
}
int Menu(){
    int opcao;
    printf("\n[1]Criar o arquivo de dados\n[2]Incluir um determinado registro no arquivo\n[3]Excluir um determinado vendedor no arquivo\n[4]Alterar o valor de uma venda no arquivo\n[5]Imprimir os registros na saida padrao\n[6]Excluir o arquivo de dados\n[7]Finalizar o programa\nDigite: ");
    scanf("%d", &opcao);
    return opcao;
}
void CriarArquivo(char arquivo[]){
    FILE *file = fopen(arquivo,"wb");
    if(file){
        printf("Arquivo criado com sucesso!\n");
        fclose(file);
    }else printf("Erro ao criar arquivo!");
}
int EscreverRegistro(char arquivo[], dados **p, int cont){
    dados *novo = malloc(sizeof(dados));
    printf("Digite codigo do vendedor: ");
    scanf("%d", &novo->cod);
    getchar();
    printf("Digite nome do vendedor: ");
    scanf("%[^\n]", novo->nome);
    printf("Digite valor da venda: ");
    scanf("%f", &novo->valor);
    printf("Digite mes: ");
    scanf("%d", &novo->mes);
    p[cont] = novo;

    FILE *file = fopen(arquivo,"rb+");
    if(file){
        //Procura por registros existentes
        for(int i=0; i<cont; i++){
            if(p[i]->cod==novo->cod && p[i]->mes==novo->mes){
                printf("Registro ja existente!\n");
                fclose(file);
            }
        }
        //Insere registro no arquivo
        fseek(file, 0, SEEK_SET);
        int pos = 0;
        for(int i=0; i<cont; i++){
            if(p[i]->cod>novo->cod || (p[i]->cod==novo->cod && p[i]->mes>novo->mes)) break;
            pos++;
        }
        fseek(file, pos*sizeof(dados), SEEK_SET);
        memmove(novo, p[pos], sizeof(dados));
        fwrite(novo, sizeof(dados), 1, file);
        for(int i=pos; i<cont; i++) fwrite(p[i], sizeof(dados), 1, file);

        fclose(file);
        printf("Registro incluido com sucesso!\n");
        return 1;
    }else{
        printf("Erro ao abrir o arquivo!\n");
        return 0;
    } 
}
int ExcluirRegistro(char arquivo[], dados **p, int cont){
    int cod, mes;
    printf("Digite codigo do vendedor e mes: ");
    scanf("%d%d", &cod, &mes);

    FILE *file = fopen(arquivo,"rb+");
    if(file){
        int pos = -1;
        for(int i=0; i<cont; i++){
            if(p[i]->cod==cod && p[i]->mes==mes) pos = i;
        } 

        if(pos==-1){
            printf("Registro nao encontrado!\n");
            fclose(file);
            return 0;
        }else{
            fseek(file, 0, SEEK_SET);
            for(int i=0; i<cont; i++){
                if(i!=pos) fwrite(&p[i], sizeof(dados), 1, file);
            } 
            fclose(file);
            dados *aux = malloc(sizeof(dados));
            for(int i=pos; i<cont; i++){
                if(pos!=cont-1){
                aux = p[pos+1];
                p[i] = aux;
                }else{
                    free(p[pos]);
                    break;
                } 
            }
            fseek(file, 0, SEEK_SET);
            for(int i=0; i<cont; i++) fwrite(p[i], sizeof(dados), 1, file);

            fclose(file);
            printf("Registro excluido com sucesso!\n");
            return -1;
        }
    }else{
        printf("Erro ao abrir o arquivo!\n");
        return 0;
    } 
}
void AlterarValor(char arquivo[], dados **p, int cont){
    int cod, mes;
    printf("Digite codigo do vendedor e mes: ");
    scanf("%d%d", &cod, &mes);

    FILE *file = fopen(arquivo,"rb+");
    if(file){
        int pos = -1;
        for(int i=0; i<cont; i++){
            if(p[i]->cod==cod && p[i]->mes==mes) pos = i;
        } 

        if(pos==-1){
            printf("Registro nao encontrado!\n");
            fclose(file);
        }else{
            printf("Digite novo valor: ");
            scanf("%f", &p[pos]->valor);
            fseek(file, pos*sizeof(dados), SEEK_SET);
            fwrite(p[pos], sizeof(dados), 1, file);

            fclose(file);
            printf("Valor da venda alterado com sucesso!\n");
        }
    }else printf("Erro ao abrir o arquivo!\n");
}
void ImprimirRegistro(char arquivo[], dados **p, int cont){
    FILE *file = fopen(arquivo,"rb");
    if(file){
        for(int i=0; i<cont; i++) printf("\nVENDEDOR %d\nCodigo: %d\nNome: %s\nValor da venda: %.2f\nMes: %d\n", i+1, p[i]->cod, p[i]->nome, p[i]->valor, p[i]->mes);
        fclose(file);
    }else printf("Erro ao abrir o arquivo!\n");
}
void ExcluirArquivo(char arquivo[]){
    if(remove(arquivo)!=0) printf("Erro ao remover arquivo!\n");
    else{
        remove(arquivo);
        printf("Arquivo removido com sucesso!\n");
    }
}