#include <stdio.h>

int main()
{
    FILE *file = fopen("2Compras.txt","r");
    if(file==NULL){
        printf("Erro ao abrir o arquivo!\n");
        return 1;
    }
    int quantidade;
    float valor, total = 0;
    char nome[50];
    do{
        fscanf(file, "%s %d %f", nome, &quantidade, &valor);
        total += quantidade * valor;
    }while(!feof(file));
    fclose(file);
    printf("Total da compra: %.2f\n", total);

    return 0;
}