#include <stdio.h>

int main()
{
    FILE *file = fopen("3Nascimento.txt","r");
    if(file==NULL){
        printf("Erro ao abrir o arquivo!\n");
        return 1;
    }
    FILE *arq = fopen("3Idade","w");
    int dia, mes, ano, dia1, mes1, ano1, idade;
    char nome[40];
    printf("Digite a data atual(dia/mes/ano): ");
    scanf("%d%d%d", &dia1, &mes1, &ano1);
    while(!feof(file)){
        fscanf(file, "%s %d %d %d", nome, &dia, &mes, &ano);
        if(mes1>mes) idade = ano1 - ano;
        else if(mes1==mes && dia1>dia) idade = ano1 - ano;
        else idade = ano1 - ano - 1;
        fprintf(arq, "%s Idade: %d\n", nome, idade);
    }
    printf("Arquivo criado com sucesso!\n");
    fclose(arq);
    fclose(file);

    return 0;
}