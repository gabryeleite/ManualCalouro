#include <stdio.h>

typedef struct{
    int dia;
    int mes;
    int ano;
}datas;

int main() {
    datas data[2];
    int meses[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int dias, total[2];

    for(int i=0; i<2; i++){
        printf("Digite %d.o data: ", i+1);
        scanf("%d%d%d", &data[i].dia, &data[i].mes, &data[i].ano);
    }

    for(int j=0; j<2; j++){
        total[j] = data[j].dia;

        if((data[j].ano%4==0 && data[j].ano%100!=0) || data[j].ano%400==0) meses[1] = 29;

        for(int i=0; i<data[j].mes - 1; i++){
            total[j] += meses[i];
        }
        if(j==1){
            for(int i=data[0].ano; i<data[j].ano; i++){
                if((i%4==0 && i%100!=0) || i%400==0) total[j] += 366;
                else total[j] += 365;
            }
        }
    }
    dias = total[1] - total[0];
    printf("Tempo decorrido: %d dias\n", dias);

    return 0;
}