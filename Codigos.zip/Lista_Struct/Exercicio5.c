#include <stdio.h>

typedef struct{
    int mat;
    char nome[40];
    int nota[3];
}info;

int main()
{
    info aluno[5];
    int N;
    float maior, media, soma = 0;

    for(int i=0; i<5; i++){
        printf("ALUNO %d\n", i+1);
        printf("Digite numero de matricula: ");
        scanf("%d", &aluno[i].mat);
        printf("Digite nome: ");
        scanf(" %[^\n]", aluno[i].nome);
        for(int j=0; j<3; j++){
            printf("Digite nota %d: ", j+1);
            scanf("%d", &aluno[i].nota[j]);
            soma += aluno[i].nota[j];
        }
        media = soma/3.0;
        soma = 0;
        if(i==0 || media>maior){
            maior = media;
            N = i;
        }
    }
    printf("\n");
    printf("Aluno com maior media: %s\nNota 1: %d\nNota 2: %d\nNota 3: %d", aluno[N].nome, aluno[N].nota[0], aluno[N].nota[1], aluno[N].nota[2]);

    return 0;
}