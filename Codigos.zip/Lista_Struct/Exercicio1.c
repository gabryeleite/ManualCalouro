#include <stdio.h>

typedef struct{
    char nome[20];
    int idade;
    char end[50];
}info;

int main()
{
    info data;

    printf("Digite nome: ");
    scanf(" %s", data.nome);
    printf("Digite idade: ");
    scanf("%d", &data.idade);
    printf("Digite endereco: ");
    scanf(" %s", data.end);
    printf("DADOS:\nNome: %s\nIdade: %d\nEndereco: %s\n", data.nome, data.idade, data.end);

    return 0;
}