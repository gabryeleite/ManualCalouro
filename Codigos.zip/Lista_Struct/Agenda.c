#include <stdio.h>
#include <string.h>
#include <stdbool.h>

typedef struct{
    char nome[40];
    char num[12];
}info;

char Read();

int main(){
    info agenda[5];
    char resp;
    char nome[40];
    int i=0;
    bool teste = false;
    char novonum[12];
    resp = Read();
    while(resp!='5'){
        if(resp=='1'){
            if(i<5){
            printf("Nome: ");
            scanf(" %s", agenda[i].nome);
            printf("Numero: ");
            scanf(" %s", agenda[i].num);
            i++;
            }else{
                printf("Limite de contados atingido!\n");
            }
        }else if(resp=='2'){
            printf("Digite nome: ");
            scanf(" %s", nome);
            for(int j=0; j<5; j++){
                if(strcmp(nome, agenda[j].nome)==0){
                    printf("Numero: %s\n", agenda[j].num);
                    teste=true;
                    break;
                }
            }
            if(teste==false){
                printf("Contato nao encontrado!\n");
            }
        }else if(resp=='3'){
            printf("Digite nome: ");
            scanf(" %s", nome);
            for(int j=0; j<5; j++){
                if(strcmp(nome, agenda[j].nome)==0){
                    //deletar string
                    for(int k=j; k<5; k++){
                        strcpy(agenda[k].nome, agenda[k+1].nome);
                        strcpy(agenda[k].num, agenda[k+1].num);
                    }
                    printf("Contato deletado!\n");
                    teste=true;
                    i--;
                    break;
                }
            }
            if(teste==false){
                printf("Contato nao encontrado!\n");
            }
        }else if(resp=='4'){
            printf("Digite nome: ");
            scanf(" %s", nome);
            for(int j=0; j<5; j++){
                if(strcmp(nome, agenda[j].nome)==0){
                    printf("Numero: %s\n", agenda[j].num);
                    printf("Digite novo numero: ");
                    scanf(" %s", novonum);
                    strcpy(agenda[j].num, novonum);
                    printf("Contato atualizado!\n");
                    teste=true;
                    break;
                }
            }
            if(teste==false){
                printf("Contato nao encontrado!\n");
            }
        }
        teste = false;
        system("pause");
        system("cls");
        resp = Read();
    }

    return 0;
}
char Read(){
    char resp;
    printf("[1]Inserir novo contato\n");
    printf("[2]Pesquisar contato\n");
    printf("[3]Remover contato\n");
    printf("[4]Editar contato\n");
    printf("[5]Sair\n");
    scanf(" %c", &resp);
    return resp;
}