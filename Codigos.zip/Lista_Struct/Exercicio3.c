#include <stdio.h>
#include <math.h>

typedef struct{
    int X;
    int Y;
}ponto;

typedef struct{
    ponto esquerdo;
    ponto direito;
}retangulo;

int main()
{
    retangulo retan;
    float diagonal, h, base;

    printf("Digite ponto superior esquerdo[X,Y]: ");
    scanf("%d%d", &retan.esquerdo.X, &retan.esquerdo.Y);
    printf("Digite ponto inferior direito[X,Y]: ");
    scanf("%d%d", &retan.direito.X, &retan.direito.Y);
    diagonal = sqrt(pow(retan.direito.X - retan.esquerdo.X, 2) + pow(retan.direito.Y - retan.esquerdo.Y, 2));
    h = retan.esquerdo.Y - retan.direito.Y;
    base = retan.direito.X - retan.esquerdo.X;
    printf("Diagonal: %.1f\n", diagonal);
    printf("Area: %1.f\n", h*base);
    printf("Perimetro: %.1f\n", 2*h + 2*base);
    
    return 0;
}