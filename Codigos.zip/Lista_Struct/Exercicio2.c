#include <stdio.h>
#include <math.h>

typedef struct{
    int X;
    int Y;
}info;

int main()
{
    info ponto[2];
    float d;

    for(int i=0; i<2; i++){
        printf("Digite %d.o ponto[X,Y]: ", i+1);
        scanf("%d%d", &ponto[i].X, &ponto[i].Y);
    }
    d = sqrt(pow(ponto[1].X - ponto[0].X, 2) + pow(ponto[1].Y - ponto[0].Y, 2));
    printf("A distancia entre os pontos e: %.1f", d);

    return 0;
}