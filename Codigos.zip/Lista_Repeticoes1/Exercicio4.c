#include <stdio.h>

int main()
{
    int N;
    float soma=0;

    scanf("%d", &N);
    for(int i=1; i<=N; i++){
        soma += (float)(1.0/i);
    }
    printf("Soma = %.2f\n", soma);

    return 0;
}