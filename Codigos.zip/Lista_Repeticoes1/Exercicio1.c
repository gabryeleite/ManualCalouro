#include <stdio.h>

int main()
{
    int N;

    scanf("%d", &N);
    for(int i=0; i<=N; i++) printf("%d ", i);
    printf("\n");
    for(int i=N; i>=0; i--) printf("%d ", i);

    return 0;
}