#include <stdio.h>

int main()
{
    int N, maior, menor;

    scanf("%d", &N);
    maior = N;
    menor = N;
    while(N>=0){
        if(N>maior) maior = N;
        if(N<menor) menor = N;
        scanf("%d", &N);
    }
    printf("Maior = %d\n", maior);
    printf("Menor = %d\n", menor);

    return 0;
}