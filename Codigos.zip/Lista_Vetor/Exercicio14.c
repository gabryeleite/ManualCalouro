#include <stdio.h>

int main()
{
    int n[5], m[5], inter[5], cont=0, teste=0;

    for(int i=0; i<5; i++){
        printf("%d.o numero do Vetor 1: ", i+1);
        scanf("%d", &n[i]);
        printf("%d.o numero do Vetor 2: ", i+1);
        scanf("%d", &m[i]);
    }
    printf("\nInterseccao\n");
    for(int i=0; i<5; i++){
        for(int j=0; j<5; j++){
            if(n[i]==m[j]){
                if(cont==0){
                    inter[cont] = n[i];
                    printf("%d ", inter[cont]);
                    cont++;
                }else{
                    inter[cont] = n[i];
                    for(int k=0; k<cont; k++){
                        if(inter[cont]==inter[k]) teste++;
                    }
                    if(teste==0){
                        printf("%d ", inter[cont]);
                        cont++;
                    }
                    teste = 0;
                }
                break;
            }
        }
    }

    return 0;
}