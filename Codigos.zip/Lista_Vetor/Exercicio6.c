#include <stdio.h>

int main()
{
    int n[30], cont=1, i=0;

    while(i<30){
        if(cont%7 != 0){
            n[i] = cont;
            printf("%d ", n[i]);
            i++;
        }
        cont++;
    }

    return 0;
}