#include <stdio.h>
#include <string.h>

int main() 
{
    char str[4][30];
    char temp[30];

    printf("Digite 4 strings:\n");
    for(int i=0; i<4; i++) scanf("%s", str[i]);
    for(int i=0; i<4; i++){
        for(int j=i+1; j<4; j++){
            if(strcmp(str[i], str[j])>0){
                strcpy(temp, str[i]);
                strcpy(str[i], str[j]);
                strcpy(str[j], temp);
            }
        }
    }
    printf("Ordem Alfabetica\n");
    for(int i=0; i<4; i++) printf("%s\n", str[i]);

    return 0;
}