#include <stdio.h>

int main()
{
    int n[10];

    for(int i=0; i<10; i++){
        printf("Digite um numero: ");
        scanf("%d", &n[i]);
        for(int j=0; j<i; j++){
            if(n[i]==n[j]){
                printf("Este numero ja foi digitado. Tente outro: ");
                scanf("%d", &n[i]);
                break;
            }
        }
    }
    for(int i=0; i<10; i++) printf("%d ", n[i]);

    return 0;
}