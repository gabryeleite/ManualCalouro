#include <stdio.h>

int main()
{
    double n[10], aux;

    for(int i=0; i<10; i++){
        printf("Digite o %d.o valor: ", i+1);
        scanf("%lf", &n[i]);
        for(int j=0; j<i; j++){
            if(n[j]>n[i]){
                aux = n[j];
                n[j] = n[i];
                n[i] = aux;
            }
        }
    } 
    printf("Valores Ordenados\n");
    for(int i=0; i<10; i++) printf("%.1lf  ", n[i]);

    return 0;
}