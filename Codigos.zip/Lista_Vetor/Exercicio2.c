#include <stdio.h>

int main()
{
    int n[10], maior, menor;
    
    for(int i=0; i<10; i++){
        printf("Digite o %d.o valor: ", i+1);
        scanf("%d", &n[i]);
        if(i==0){
            maior = n[i];
            menor = n[i];
        }
        if(n[i]>maior) maior = n[i];
        if(n[i]<menor) menor = n[i];
    }
    printf("Maior = %d\nMenor = %d", maior, menor);

    return 0;
}