#include <stdio.h>

int main()
{
    int n[6];

    for(int i=0; i<6; i++){
        printf("Digite o %d.o valor: ", i+1);
        scanf("%d", &n[i]);
    } 
    printf("Ordem inversa:\n");
    for(int j=5; j>=0; j--) printf("%d ", n[j]);

    return 0;
}