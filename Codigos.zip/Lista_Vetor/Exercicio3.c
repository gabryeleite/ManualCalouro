#include <stdio.h>
#include <math.h>

int main()
{
    float n[10], m[10];
    for(int i=0; i<10; i++){
        printf("Digite o %d.o valor: ", i+1);
        scanf("%f", &n[i]);
        m[i] = pow(n[i], 2);
    }
    for(int i=0; i<10; i++) printf("%d.o valor = %.2f | Ao quadrado = %.2f\n", i+1, n[i], m[i]);

    return 0;
}