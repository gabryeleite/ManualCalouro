#include <stdio.h>

int main()
{
    char n[100];
    int i=0;
    
    printf("Escreva: ");
    scanf("%s", n);
    while(n[i]!='\0') i++;
    printf("Quantidade caracteres = %d", i);

    return 0;
}