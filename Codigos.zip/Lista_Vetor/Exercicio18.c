#include <stdio.h>

int main()
{
    int a[10], b[10], soma[10], sub[10], mult[10];

    for(int i=0; i<10; i++){
        printf("%d.o numero do Vetor 1: ", i+1);
        scanf("%d", &a[i]);
        printf("%d.o numero do Vetor 2: ", i+1);
        scanf("%d", &b[i]);
        soma[i] = a[i] + b[i];
        sub[i] = a[i] - b[i];
        mult[i] = a[i] * b[i];
    }
    printf("Soma dos Vetores:\n");
    for(int i=0; i<10; i++) printf("%d ", soma[i]);
    printf("\nSubtracao dos Vetores:\n");
    for(int i=0; i<10; i++) printf("%d ", sub[i]);
    printf("\nMultiplicacao dos Vetores:\n");
    for(int i=0; i<10; i++) printf("%d ", mult[i]);

    return 0;
}