#include <stdio.h>
#include <string.h>

int main()
{
    char n[30];
    int size, aux;

    printf("Escreva: ");
    scanf("%s", n);
    size = strlen(n);
    aux = size-1;
    for(int i=0; i<size/2; i++){
        if(n[i]!=n[aux]){
            printf("Nao eh Palindromo\n");
            return 0;
        }
        aux--;
    }
    printf("Eh Palindromo\n");

    return 0;
}