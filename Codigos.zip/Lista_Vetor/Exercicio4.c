#include <stdio.h>

int main()
{
    int n[10], m[10], cont=0, teste;

    for(int i=0; i<10; i++){
        printf("Digite um numero: ");
        scanf("%d", &n[i]);
        for(int j=0; j<i; j++){
            if(n[i]==n[j]){
                if(cont==0){
                    m[cont] = n[i];
                    cont++;
                }else{
                    for(int k=0; k<cont; k++){
                        if(n[i]==m[k]) teste++;
                    }
                    if(teste==0){
                        m[cont] = n[i];
                        cont++;
                    }
                    teste = 0;
                }
            }
        }
    }
    printf("Valores iguais:\n");
    for(int i=0; i<cont; i++) printf("%d ", m[i]);

    return 0;
}