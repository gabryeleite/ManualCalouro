#include <stdio.h>
#include <string.h>

int main()
{
    char n[30];
    int size;

    printf("Escreva: ");
    scanf("%s", n);
    size = strlen(n);
    for(int i=size-1; i>=0; i--) printf("%c", n[i]);

    return 0;
}