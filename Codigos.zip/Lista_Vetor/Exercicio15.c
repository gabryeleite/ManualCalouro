#include <stdio.h>

int main()
{
    int n[10], aux;

    for(int i=0; i<10; i++){
        printf("Digite o %d.o valor: ", i+1);
        scanf("%d", &n[i]);
        for(int j=0; j<i; j++){
            if(n[j]>n[i]){
                aux = n[j];
                n[j] = n[i];
                n[i] = aux;
            }
        }
    } 
    printf("Valores Ordenados\n");
    for(int i=0; i<10; i++) printf("%d ", n[i]);

    return 0;
}