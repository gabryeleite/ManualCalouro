#include <stdio.h>

int main()
{
    int num, aux, j=0, k=0;

    printf("Digite quantidade: ");
    scanf("%d", &num);
    int n[num], par[num], impar[num];

    for(int i=0; i<num; i++){
        printf("Digite o %d.o valor: ", i+1);
        scanf("%d", &n[i]);
        for(int j=0; j<i; j++){
            if(n[j]>n[i]){
                aux = n[j];
                n[j] = n[i];
                n[i] = aux;
            }
        }
    } 
    printf("Vetor Ordenado\nPares Crescentes:\n");
    for(int i=0; i<num; i++){
        if(n[i]%2==0){
            par[j] = n[i];
            printf("%d ", par[j]);
            j++;
        }else{
            impar[k] = n[i];
            k++;
        }
    } 
    printf("\nImpares Decresecentes\n");
    for(int i=k-1; i>=0; i--) printf("%d ", impar[i]);

    return 0;
}