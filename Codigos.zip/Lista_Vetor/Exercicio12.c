#include <stdio.h>
#include <string.h>

int main()
{
    char n[30], cons;
    int size, cont = 0;

    printf("Escreva: ");
    gets(n);
    size = strlen(n);
    printf("Digite consoante: ");
    scanf("%c", &cons);
    for(int i=0; i<size; i++){
        if(n[i]=='a' || n[i]=='e' || n[i]=='i' || n[i]=='o' || n[i]=='u'){
            n[i] = cons;
            cont++;
        }
    }
    printf("Numero vogais: %d\nSubstituicao: %s", cont, n);

    return 0;
}