#include <stdio.h>
#include <string.h>

int main()
{
    char n[100], m[100];
    char *p;

    printf("Escreva a primeira string: ");
    scanf("%s", n);
    printf("Escreva a segunda string: ");
    scanf("%s", m);
    p = strstr(n, m);
    if(p!=NULL) printf("Segunda string ESTA contida na primeira\n");
    else printf("Segunda string NAO esta contida na primeira\n");

    return 0;
}