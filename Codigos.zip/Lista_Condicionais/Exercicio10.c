#include <stdio.h>

int main()
{
    float preco;
    int n;

    printf("Digite preco: ");
    scanf("%f", &preco);
    printf("Escolha forma de pagamento: \n[1] A vista em dinheiro ou cheque\n[2] A vista no cartao de credito\n[3] Em duas vezes\n[4] Em tres ou mais vezes\n");
    scanf("%d", &n);
    if(n==1) printf("10%% de desconto\nValor final: %.2f", preco-preco*0.1);
    else if(n==2) printf("15%% de desconto\nValor final: %.2f", preco-preco*0.15);
    else if(n==3) printf("Sem desconto\nValor final: 2 vezes de %.2f", preco/2);
    else printf("10%% de juros\nValor final: %.2f", preco+preco*0.1);

    return 0;
}