#include <stdio.h>

int main()
{
    float d, comb;
    
    printf("Digite a distancia e combustivel consumido: ");
    scanf("%f%f", &d, &comb);
    printf("Consumo medio = %.2f", d/comb);

    return 0;
}