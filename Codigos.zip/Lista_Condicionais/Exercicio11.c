#include <stdio.h>

int main()
{
    int mat;
    float n1, n2, n3, me, mt;

    printf("Digite n de matricula: ");
    scanf("%d", &mat);
    printf("Digite as tres notas: ");
    scanf("%f%f%f", &n1, &n2, &n3);
    printf("Digite media dos exercicios: ");
    scanf("%f", &me);
    mt = (float)(n1 + n2 + n3 + me)/4;
    if(mt<40) printf("MATRICULA: %d\nNota1: %.2f, Nota2: %.2f, Nota3: %.2f\nMedia Total: %.2f\nConceito E\nREPROVADO", mat, n1, n2, n3, mt);
    else if(mt<60) printf("MATRICULA: %d\nNota1: %.2f, Nota2: %.2f, Nota3: %.2f\nMedia Total: %.2f\nConceito D\nREPROVADO", mat, n1, n2, n3, mt);
    else if(mt<75) printf("MATRICULA: %d\nNota1: %.2f, Nota2: %.2f, Nota3: %.2f\nMedia Total: %.2f\nConceito C\nAPROVADO", mat, n1, n2, n3, mt);
    else if(mt<90) printf("MATRICULA: %d\nNota1: %.2f, Nota2: %.2f, Nota3: %.2f\nMedia Total: %.2f\nConceito B\nAPROVADO", mat, n1, n2, n3, mt);
    else printf("MATRICULA: %d\nNota1: %.2f, Nota2: %.2f, Nota3: %.2f\nMedia Total: %.2f\nConceito A\nAPROVADO", mat, n1, n2, n3, mt);

    return 0;
}