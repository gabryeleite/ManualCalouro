#include <stdio.h>

int main()
{
    float r;

    scanf("%f", &r);
    if(r<0) printf("Impossivel, raio menor que 0\n");
    else printf("Area do circulo = %.2f", 3.14*(r*r));

    return 0;
}