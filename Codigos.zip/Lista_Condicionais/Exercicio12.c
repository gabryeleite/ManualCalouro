#include <stdio.h>

int main()
{
    int n, a, b;

    printf("Escolha a Operacao: \n[1] Soma\n[2] Subtracao\n[3] Multiplicacao\n[4] Divisao\n");
    scanf("%d", &n);
    printf("Digite dois valores: ");
    scanf("%d%d", &a, &b);
    if(n==1) printf("Soma = %d", a+b);
    else if(n==2) printf("Subtracao = %d", a-b);
    else if(n==3) printf("Multiplicacao = %d", a*b);
    else printf("Divisao = %.2f", (float)a/b);

    return 0;
}