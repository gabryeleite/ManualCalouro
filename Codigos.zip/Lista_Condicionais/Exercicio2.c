#include <stdio.h>

int main()
{
    int n, teste=0;

    scanf("%d", &n);
    if(n%3==0) teste++;
    if(n%5==0) teste++;

    if(teste==1) printf("Esta de acordo\n");
    else printf("Nao esta de acordo\n");

    return 0;
}