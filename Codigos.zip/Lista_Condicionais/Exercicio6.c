#include <stdio.h>

int main()
{
    float sal, emp;

    printf("Digite Salario e Emprestimo: ");
    scanf("%f%f", &sal, &emp);
    if(emp > sal*0.2) printf("Emprestimo nao concedido\n");
    else printf("Emprestimo concedido\n");

    return 0;
}