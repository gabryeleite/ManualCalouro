#include <stdio.h>

int main()
{
    int n;
    float x, y, z, total;

    printf("Digite tres numeros: ");
    scanf("%f%f%f", &x, &y, &z);
    printf("Escolha a Media: \n[1] Geometrica\n[2] Ponderada\n[3] Harmonica\n[4] Aritmetica\n");
    scanf("%d", &n);
    if(n==1) total = x*y*z;
    else if(n==2) total = (float)(x + 2*y + 3*z)/6;
    else if(n==3) total = (float)1/(1/x + 1/y + 1/z);
    else total = (x + y + z)/3;

    printf("Resultado: %.2f", total);

    return 0;
}