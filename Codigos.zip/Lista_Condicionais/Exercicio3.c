#include <stdio.h>
#include <math.h>

int main()
{
    float a, b, c, delta, x1, x2;

    printf("Digite tres valores: ");
    scanf("%f%f%f", &a, &b, &c);
    if(a==0) printf("Nao eh equacao do segundo grau\n");
    else{
        delta = (b*b - 4*a*c);
        if(delta<0) printf("Nao existe raiz\n");
        else if(delta>0){
            x1 = (-b + sqrt(delta))/2*a;
            x2 = (-b - sqrt(delta))/2*a;
            printf("X1 = %.2f e X2 = %.2f", x1, x2);
        }else{
            x1 = (-b + sqrt(delta))/2*a;
            printf("Raiz unica = %.2f", x1);
        }
    }

    return 0;
}