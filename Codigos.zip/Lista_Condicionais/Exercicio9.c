#include <stdio.h>

int main()
{
    float peso, h, imc;

    printf("Digite peso e altura: ");
    scanf("%f%f", &peso, &h);
    imc = peso/(h*h);
    if(imc<18.5) printf("Abaixo do peso\n");
    else if(imc<25) printf("Peso normal\n");
    else if(imc<30) printf("Acima do peso\n");
    else printf("Obeso\n");

    return 0;
}