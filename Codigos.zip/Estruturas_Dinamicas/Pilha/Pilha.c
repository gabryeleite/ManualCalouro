#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int dia;
    int mes;
    int ano;
} Data;

typedef struct{
    char nome[40];
    Data data;
} Pessoa;

typedef struct aux{
    Pessoa pessoa;
    struct aux *prox;
} No;

typedef struct{
    No *inicio;
    int tam;
} Pilha;

int Menu();
Pessoa LerPessoa();
void PrintPessoa(Pessoa p);
void Iniciar(Pilha *p);
void Push(Pilha *p);
void Pop(Pilha *p);
void PrintPilha(Pilha *p);
void Reiniciar(Pilha *p);

int main()
{
    Pilha *pilha = malloc(sizeof(Pilha));
    int op;

    do{
        op = Menu();
        getchar();
        switch(op){
        case 1:
            Iniciar(pilha);
            break;
        case 2:
            Push(pilha);
            break;
        case 3:
            Pop(pilha);
            break;
        case 4:
            PrintPilha(pilha);
            break;
        case 5:
            printf("Numero de elementos: %d\n", pilha->tam);
            break;
        case 6:
            Reiniciar(pilha);
            break;
        case 7:
            printf("Programa finalizado!\n");
            break;
        default:
            printf("Opcao Invalida!\n");
        break;
        }
    }while(op!=7);

    return 0;
}

int Menu(){
    int N;
    printf("\n[1]Inicializar\n[2]Empilhar\n[3]Desempilhar\n[4]Imprimir\n[5]Quantidade\n[6]Reiniciar\n[7]Sair\nEscolha: ");
    scanf("%d", &N);
    return N;
}

Pessoa LerPessoa(){
    Pessoa p;
    printf("Digite nome: ");
    scanf("%[^\n]", p.nome);
    printf("Digite dia/mes/ano: ");
    scanf("%d%d%d", &p.data.dia, &p.data.mes, &p.data.ano); 
    return p;
}

void PrintPessoa(Pessoa p){
    printf("\nNome: %s\nData: %2d/%2d/%4d\n", p.nome, p.data.dia, p.data.mes, p.data.ano);
}

void Iniciar(Pilha *p){
    p->inicio = NULL;
    p->tam = 0;
    printf("Pilha inicializada!\n");
}

void Push(Pilha *p){
    No *novo = malloc(sizeof(No));
    if(novo){
        novo->pessoa = LerPessoa();
        novo->prox = p->inicio;
        p->inicio = novo;
        p->tam++;
        printf("Elemento inserido com sucesso!\n");
    }else printf("Erro ao alocar memoria!\n");
}

void Pop(Pilha *p){
    No *end = p->inicio;
    if(p->inicio){
        No *apagar = end;
        p->inicio = end->prox;
        PrintPessoa(apagar->pessoa);
        p->tam--;
        free(apagar);
        printf("Elemento removido com sucesso!\n");
    }else printf("Pilha vazia!\n");
}

void PrintPilha(Pilha *p){
    No *end = p->inicio;
    while(end->prox){
        PrintPessoa(end->pessoa);
        end = end->prox;
    }
}

void Reiniciar(Pilha *p){
    No *end = p->inicio;
    while(end){
        No *apagar = end;
        end = end->prox;
        free(apagar);
    }
    p->inicio = NULL;
    p->tam = 0;
    printf("Estrutura reinicializada!\n");
}