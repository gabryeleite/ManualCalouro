#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int dia;
    int mes;
    int ano;
} Data;

typedef struct{
    char nome[40];
    Data data;
} Pessoa;

typedef struct aux{
    Pessoa pessoa;
    struct aux *prox;
} Pilha;

int Menu();
Pessoa LerPessoa();
void PrintPessoa(Pessoa p);
Pilha* Iniciar(Pilha *topo);
Pilha* Push(Pilha *topo);
Pilha* Pop(Pilha **topo);
void PrintPilha(Pilha *topo);
int Quantidade(Pilha *topo);
void FimPilha(Pilha *topo);

int main()
{
    Pilha *apagar, *topo = malloc(sizeof(Pilha));
    int op, quant;

    do{
        op = Menu();
        getchar();
        switch(op){
        case 0:
            topo = Iniciar(topo);
            break;
        case 1:
            topo = Push(topo);
            break;
        case 2:
            apagar = Pop(&topo);
            if(apagar){
                printf("Elemento removido com sucesso!\n");
                PrintPessoa(apagar->pessoa);
            } 
            break;
        case 3:
            PrintPilha(topo);
            break;
        case 4:
            quant = Quantidade(topo);
            printf("Numero de elementos: %d\n", quant);
            break;
        case 5:
            FimPilha(topo);
            printf("Programa Finalizado!\n");
            break;
        default:
            printf("Opcao Invalida!\n");
        break;
        }
    }while(op!=5);

    return 0;
}
int Menu(){
    int N;
    printf("\n[0]Inicializar\n[1]Empilhar\n[2]Desempilhar\n[3]Imprimir\n[4]Quantidade\n[5]Sair\nEscolha: ");
    scanf("%d", &N);
    return N;
}
Pessoa LerPessoa(){
    Pessoa p;
    printf("Digite nome: ");
    scanf("%[^\n]", p.nome);
    printf("Digite dia/mes/ano: ");
    scanf("%d%d%d", &p.data.dia, &p.data.mes, &p.data.ano); 
    return p;
}
void PrintPessoa(Pessoa p){
    printf("\nNome: %s\nData: %2d/%2d/%4d\n", p.nome, p.data.dia, p.data.mes, p.data.ano);
}
Pilha* Iniciar(Pilha *topo){
    topo = NULL;
    printf("Pilha inicializada!\n");
    return topo;
}
Pilha* Push(Pilha *topo){
    Pilha *novo = malloc(sizeof(Pilha));
    if(novo){
        novo->pessoa = LerPessoa();
        novo->prox = topo;
        printf("Elemento inserido com sucesso!\n");
        return novo;
    }else{
        printf("Erro ao alocar memoria!\n");
        return NULL;
    }
}
Pilha* Pop(Pilha **topo){
    if(*topo){
        Pilha *apagar = *topo;
        *topo = apagar->prox;
        return apagar;
    }else{
        printf("Pilha vazia!\n");
        return NULL;
    }
}
void PrintPilha(Pilha *topo){
    while(topo){
        PrintPessoa(topo->pessoa);
        topo = topo->prox;
    }
}
int Quantidade(Pilha *topo){
    int quant = 0;
    while(topo){
        topo = topo->prox;
        quant++;
    }
    return quant;
}
void FimPilha(Pilha *topo){
    Pilha *end = topo;
    while(end){
        Pilha *apagar = end;
        end = end->prox;
        free(apagar);
    }
    topo = NULL;
}