#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int num;
    char nome[40];
} data;

typedef struct aux{
    struct aux *prox;
    data dado;
} No;

typedef struct{
    No *inicio;
    int tam;
} Pilha;

int Menu(){
    int N;
    printf("\n[1]Inicializar\n[2]Empilhar\n[3]Desempilhar\n[4]Imprimir\n[5]Quantidade\n[6]Reiniciar\n[7]Sair\nEscolha: ");
    scanf("%d", &N);
    getchar();

    return N;
}

void Inicializa(Pilha *p){
    p->inicio = NULL;
    p->tam = 0;
    printf("Pilha Inicializada!\n");
}

void Push(Pilha *p){
    No *novo = malloc(sizeof(No));

    printf("Digite nome: ");
    scanf("%[^\n]", novo->dado.nome);
    printf("Digite idade: ");
    scanf("%d", &novo->dado.num);

    novo->prox = p->inicio;
    p->inicio = novo;
    p->tam++;
    printf("Elemento inserido com sucesso!\n");
}

void Pop(Pilha *p){
    No *end = p->inicio;
    if(p->inicio){
        No *apagar = end;
        p->inicio = end->prox;
        printf("Nome: %s\nIdade: %d\nElemento removido com sucesso!\n", end->dado.nome, end->dado.num);
        p->tam--;
        free(apagar);
    }else printf("Pilha vazia!\n");
}

void Imprimir(Pilha *p){
    No *end = p->inicio;
    while(end){
        printf("Nome: %s\nIdade: %d\n", end->dado.nome, end->dado.num);
        end = end->prox;
    }
}

void Quantidade(Pilha *p){
    printf("Quantidade de elementos: %d\n", p->tam);
}

void Reiniciar(Pilha *p){
    No *end = p->inicio;
    while(end){
        No *apagar = end;
        end = end->prox;
        free(apagar);
    }
    p->inicio = NULL;
    p->tam = 0;
}

int main()
{
    int N;
    Pilha *pilha = malloc(sizeof(Pilha));

    do{
        N = Menu();

        switch(N){
        case 1:
            Inicializa(pilha);
            break;
        case 2:
            Push(pilha);
            break;
        case 3:
            Pop(pilha);
            break;
        case 4:
            Imprimir(pilha);
            break;
        case 5:
            Quantidade(pilha);
            break;
        case 6:
            Reiniciar(pilha);
        case 7:
            printf("Programa finalizado!\n");
        default:
            printf("Opcao invalida!\n");
            break;
        }
    }while(N != 7);

    return 0;
}