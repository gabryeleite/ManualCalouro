#include <stdio.h>
#include <stdlib.h>
#include "PilhaFunc.c"

int main()
{
    Pilha *pilha = malloc(sizeof(Pilha));
    int op;

    do{
        op = Menu();
        getchar();
        switch(op){
        case 1:
            Iniciar(pilha);
            break;
        case 2:
            Push(pilha);
            break;
        case 3:
            Pop(pilha);
            break;
        case 4:
            PrintPilha(pilha);
            break;
        case 5:
            printf("Numero de elementos: %d\n", pilha->tam);
            break;
        case 6:
            Reiniciar(pilha);
            break;
        case 7:
            printf("Programa finalizado!\n");
            break;
        default:
            printf("Opcao Invalida!\n");
        break;
        }
    }while(op!=7);

    return 0;
}