#ifndef PILHA_H_INCLUDED
#define PILHA_H_INCLUDED

typedef struct{
    int dia;
    int mes;
    int ano;
} Data;

typedef struct{
    char nome[40];
    Data data;
} Pessoa;

typedef struct aux{
    Pessoa pessoa;
    struct aux *prox;
} No;

typedef struct{
    No *inicio;
    int tam;
} Pilha;

int Menu();
Pessoa LerPessoa();
void PrintPessoa(Pessoa p);
void Iniciar(Pilha *p);
void Push(Pilha *p);
void Pop(Pilha *p);
void PrintPilha(Pilha *p);
void Reiniciar(Pilha *p);

#endif