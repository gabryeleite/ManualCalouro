#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct{
    char nome[40];
    int cod;
    char empresa[40];
    char problem;
} Aviao;

typedef struct aux{
    Aviao aviao;
    struct aux *prox;
} No;

typedef struct{
    No *inicio;
    No *fim;
    int tam;
} Fila;

void Inicia(Fila *f);
int Menu();
bool Dados(No *novo);
void Adicionar(Fila *f);
void Remover(Fila *f);
void Imprimir(Fila *f);
void Caracteristica(Fila *f);

int main(){
    Fila *fila = malloc(sizeof(Fila));
    Inicia(fila);
    int op;

    do{
        op = Menu();
        switch(op){
            case 1:
                Adicionar(fila);
                break;
            case 2:
                Remover(fila);
                break;
            case 3:
                printf("Quantidade de avioes na fila: %d\n", fila->tam);
                break;
            case 4:
                Imprimir(fila);
                break;
            case 5:
                Caracteristica(fila);
                break;
            case 6:
                printf("Programa finalizado!\n");
                break;
            default:
                printf("Opcao invalida!\n");
            break;
        }
    }while(op != 6);

    return 0;
}

void Inicia(Fila *f){
    f->inicio = NULL;
    f->fim = NULL;
    f->tam = 0;
}

int Menu(){
    int N;
    printf("\n[1]Adicionar aviao\n[2]Autorizar decolagem\n[3]Quantidade na fila\n[4]Listar avioes na fila\n[5]Listar caracteristica do primeiro\n[6]Sair\nEscolha: ");
    scanf("%d", &N);
    getchar();

    return N;
}

bool Dados(No *novo){
    printf("Digite nome do aviao: ");
    scanf("%[^\n]", novo->aviao.nome);
    getchar();
    printf("Digite nome da empresa: ");
    scanf("%[^\n]", novo->aviao.empresa);
    printf("Digite codigo do aviao: ");
    scanf("%d", &novo->aviao.cod);
    getchar();
    printf("Aviao esta com problemas mecanicos?[S/N]: ");
    scanf("%c", &novo->aviao.problem);

    if(novo->aviao.problem == 'N') return false;
    else return true;

}

void Adicionar(Fila *f){
    No *novo = malloc(sizeof(No));
    bool problem;
    if(novo){
        problem = Dados(novo);
        novo->prox = NULL;
        if(f->inicio == NULL){
            f->inicio = novo;
            f->fim = novo;
        }else{
            if(problem){
                if(f->inicio->aviao.problem == 'N'){
                    novo->prox = f->inicio;
                    f->inicio = novo;
                }else{
                    No *aux = f->inicio;
                    while(aux->prox && aux->prox->aviao.problem == 'S'){
                        aux = aux->prox;
                    }
                    novo->prox = aux->prox;
                    aux->prox =  novo;
                }
            }else{
                f->fim->prox = novo;
                f->fim = novo;
            }
        }
        f->tam++;
        printf("Aviao adicionado com sucesso!\n");
    }else printf("Erro ao alocar memoria!\n");
}

void Remover(Fila *f){
    No *end = NULL;
    if(f->inicio){
        No *apagar = end;
        end = f->inicio;
        f->inicio = end->prox;
        printf("Aviao decolado: %s\n", end->aviao.nome);
        f->tam--;
        free(apagar);
    }else printf("Pista de decolagem vazia!\n");
}

void Imprimir(Fila *f){
    No *end = f->inicio;
    printf("Pista de Decolagem:\n");
    while(end){
        printf("%s\n", end->aviao.nome);
        end = end->prox;
    }
}

void Caracteristica(Fila *f){
    printf("Dados do primeiro aviao:\nNome: %s\nEmpresa: %s\nCodigo: %d\nProblemas mecanicos: %c\n", f->inicio->aviao.nome, f->inicio->aviao.empresa, f->inicio->aviao.cod, f->inicio->aviao.problem);
}