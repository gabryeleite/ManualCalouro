#include <stdio.h>
#include <stdlib.h>

typedef struct aux{
    char dado;
    struct aux *prox;
} No;

typedef struct{
    No *inicio;
} Pilha;

void Push(Pilha *p, char dado);
int Pop(Pilha *p);
int Verifica(Pilha *p, char str[]);

int main()
{
    Pilha *pilha = malloc(sizeof(Pilha));
    pilha->inicio = NULL;
    char str[100];
    int verifica;

    printf("Escreva: ");
    scanf("%[^\n]", str);

    verifica = Verifica(pilha, str);
    if(verifica != 0 || pilha->inicio != NULL) printf("Esta errado!\n");
    else printf("Esta correto!\n");

    return 0;
}

void Push(Pilha *p, char dado){
    No *novo = malloc(sizeof(No));
    if(novo){
        novo->dado = dado;
        novo->prox = p->inicio;
        p->inicio = novo;
    }else printf("Erro ao alocar memoria!\n");
}

int Pop(Pilha *p){
    No *end = p->inicio;
    if(end){
        No *apagar = end;
        p->inicio = end->prox;
        free(apagar);
    }else return 1;
    return 0;
}

int Verifica(Pilha *p, char str[]){
    int i = 0, verifica = 0;
    while(str[i] != '\0'){
        if(str[i]=='(' || str[i]=='[') Push(p, str[i]);
        else if(str[i]==')' || str[i]==']') verifica = Pop(p);
        i++; 
    }
    return verifica;
}