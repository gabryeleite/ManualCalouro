#include <stdio.h>
#include <stdlib.h>

typedef struct aux{
    char dado;
    struct aux *prox;
} No;

typedef struct{
    No *inicio;
} Pilha;

void Inicia(Pilha *p);
void Push(Pilha *p, char txt);
void Verifica(Pilha *p);

int main()
{
    Pilha *pilha = malloc(sizeof(Pilha));
    char txt;
    Inicia(pilha);

    printf("Escreva: ");
    do{
        scanf("%c", &txt);
        Push(pilha, txt);
    }while(txt != '\n');

    Verifica(pilha);

    return 0;
}

void Inicia(Pilha *p){
    p->inicio = NULL;
}

void Push(Pilha *p, char txt){
    No *novo = malloc(sizeof(No));
    if(novo){
        novo->dado = txt;
        novo->prox  = p->inicio;
        p->inicio = novo;
    }else printf("Erro ao alocar memoria!\n");
}

void Verifica(Pilha *p){
    No *end = p->inicio;
    int open = 0, close = 0;

    while(end){
        if(end->dado == '(') open++;
        else if(end->dado == ')') close++;
        end = end->prox;
    }

    if(open==close) printf("Esta correto!\n");
    else printf("Esta errado!\n");
}