#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAX_LIVRO 10

typedef struct{
    char nome[40];
    bool disponivel;
    int indice;
} Livro;

typedef struct aux{
    char nome[40];
    struct aux *prox;
} No;

typedef struct{
    No *inicio;
    No *fim;
    int tam;
} Fila;

void Inicia(Fila *f);
int Menu();
int Verifica(Livro livro[], char nome[], int num);
int Cadastrar(Livro livro[], int i);
void Push(Fila *f, char nome[], int i);
void Retirar(Fila *f, Livro livro[], int i);
void Pop(Fila *f, int i);
void Devolver(Fila *f, Livro livro[], int i);
void PrintFila(Fila *f, int i);
void Imprimir(Fila *f, Livro livro[], int indice);

int main()
{
    Fila *fila = malloc(MAX_LIVRO * sizeof(Fila));
    Inicia(fila);
    Livro livro[MAX_LIVRO];
    int op, i = 0;

    do{
        op = Menu();
        switch(op){
            case 1:
                i += Cadastrar(livro, i);
                break;
            case 2:
                Retirar(fila, livro, i);
                break;
            case 3:
                Devolver(fila, livro, i);
                break;
            case 4:
                Imprimir(fila, livro, i);
                break;
            case 5:
                printf("Programa finalizado!\n");
                break;
            default:
                printf("Opcao invalida!\n");
            break;
        }
    }while(op != 5);

    return 0;
}

void Inicia(Fila *f){
    for(int i=0; i < MAX_LIVRO; i++){
        f[i].inicio = NULL;
        f[i].fim = NULL;
        f[i].tam = 0;
    }
}

int Menu(){
    int N;
    printf("\n[1]Cadastrar lirvo\n[2]Retirar livro\n[3]Devolver livro\n[4]Imprimir biblioteca\n[5]Sair\nEscolha: ");
    scanf("%d", &N);
    getchar();
    
    return N;
}

int Verifica(Livro livro[], char nome[], int num){
    for(int i=0; i < num; i++){
        if(strcmp(nome, livro[i].nome)==0) return i;
    }
    return -1;
}

int Cadastrar(Livro livro[], int i){
    if(i >= MAX_LIVRO){
        printf("Biblioteca lotada!\n");
        return 0;
    }
    printf("Nome do livro: ");
    scanf("%[^\n]", livro[i].nome);

    int verifica = Verifica(livro, livro[i].nome, i);
    if(verifica == -1){
        livro[i].indice = i;
        livro[i].disponivel = true;
        i++;
        printf("Livro cadastrado com sucesso!\n");
    }else{
        printf("Livro ja cadastrado!\n");
        return 0;
    } 

    return 1;
}

void Push(Fila *f, char nome[], int i){
    No *novo = malloc(sizeof(No));
    if(novo){
        strcpy(novo->nome, nome);
        novo->prox = NULL;
        if(f[i].inicio==NULL){
            f[i].inicio = novo;
            f[i].fim = novo;
        }else{
            f[i].fim->prox = novo;
            f[i].fim = novo;
        }
        f[i].tam++;
    }else printf("Erro ao alocar memoria!\n");
}

void Retirar(Fila *f, Livro livro[], int i){
    char nomeL[40], nomeP[40];
    printf("Nome do livro: ");
    scanf("%[^\n]", nomeL);
    getchar();
    printf("Seu nome: ");
    scanf("%[^\n]", nomeP);

    int verifica = Verifica(livro, nomeL, i);
    if(verifica != -1){
        if(livro[verifica].disponivel==true){
            livro[verifica].disponivel = false;
            printf("Livro retirado com sucesso!\n");
        }else{
            Push(f, nomeP, verifica);
            printf("Adicionado a fila na posicao %d.\n", f[verifica].tam);
        }
    }else printf("Livro nao encontrado!\n");
}

void Pop(Fila *f, int i){
    No *end = NULL;
    if(f[i].inicio){
        end = f[i].inicio;
        No *apagar = end;
        f[i].inicio = end->prox;
        f[i].tam--;
        printf("Livro passou para %s.\n", end->nome);
        free(apagar);
    }else printf("Fila vazia!\n");
}

void Devolver(Fila *f, Livro livro[], int i){
    char nome[40];
    printf("Nome do livro: ");
    scanf("%[^\n]", nome);

    int verifica = Verifica(livro, nome, i);
    if(verifica != -1){
        if(f[verifica].tam > 0) Pop(f, verifica);
        else livro[verifica].disponivel = true;
    }else printf("Livro inexistente!\n");
}

void PrintFila(Fila *f, int i){
    No *end = f[i].inicio;
    while(end){
        printf("%s", end->nome);
        end = end->prox;
        if(end != NULL) printf(", ");
    }
    printf("\nFila: %d\n\n", f[i].tam);
}

void Imprimir(Fila *f, Livro livro[], int indice){
    printf("\nLIVROS: \n");
    for(int i=0; i<indice; i++){
        printf("%s", livro[i].nome);
        if(livro[i].disponivel==true) printf(" : Disponivel\n");
        else printf(" : Indisponivel\n");
        PrintFila(f, i);
    }
}