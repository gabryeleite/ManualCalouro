#include <stdio.h>
#include <stdlib.h>

typedef struct aux{
    char dado;
    struct aux *prox;
} No;

typedef struct{
    No *inicio;
} Pilha;

int Menu();
void Escrever(Pilha *p);
void Backspace(Pilha *p);
void Reiniciar(Pilha *p);
void Print(Pilha *p);

int main()
{
    char op;
    Pilha *pilha = malloc(sizeof(Pilha));
    pilha->inicio = NULL;

    do{
        op = Menu();
        switch(op){
            case 1:
                Escrever(pilha);
                break;
            case 2:
                Backspace(pilha);
                break;
            case 3:
                Reiniciar(pilha);
                break;
            case 4:
                Print(pilha);
                break;
            case 5:
                printf("Editor finalizado!\n");
                break;
            default:
                printf("Opcao invalida!\n");
            break;
        }
    }while(op != 5);

    return 0;
}

int Menu(){
    int N;
    printf("\n[1]Escrever\n[2]Backspace\n[3]Apagar\n[4]Visualizar\n[5]Sair\nEscolha: ");
    scanf("%d", &N);
    getchar();

    return N;
}

void Escrever(Pilha *p){
    No *novo = malloc(sizeof(No));

    if(novo){
        printf("Escreva um caracter: ");
        scanf("%c", &novo->dado);

        novo->prox = p->inicio;
        p->inicio = novo;
    }else printf("Erro ao alocar memoria!\n");
}

void Backspace(Pilha *p){
    No *end = p->inicio;

    if(p->inicio){
        No *apagar = end;
        p->inicio = end->prox;
        printf("Caracter apagado: %c\n", end->dado);
        free(apagar);
    }else printf("Editor vazio!\n");
}

void Reiniciar(Pilha *p){
    No *end = p->inicio;
    while(end){
        No *apagar = end;
        end = end->prox;
        free(apagar);
    }
    p->inicio = NULL;
    printf("Texto apagado!\n");
}

void Print(Pilha *p){
    No *end = p->inicio;
    while(end){
        printf("%c", end->dado);
        end = end->prox;
    }
    printf("\n");
}