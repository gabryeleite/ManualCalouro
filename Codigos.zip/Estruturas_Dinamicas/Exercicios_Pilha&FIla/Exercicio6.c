#include <stdio.h>
#include <stdlib.h>

typedef struct aux{
    int dado;
    struct aux *prox;
} No;

typedef struct{
    No *inicio;
    No *fim;
    int tam;
} Fila;

void Inicia(Fila *f);
int Menu();
void Adiciona(Fila *f, int i, int valor);
void Reinicia(Fila *f, int i);
void Intercalar(Fila *f);
void Imprimir(Fila *f);

int main(){
    Fila *fila = malloc(3*sizeof(Fila));
    int op, valor;
    Inicia(fila);

    do{
        op = Menu();
        switch(op){
            case 1:
                printf("Digite um valor: ");
                scanf("%d", &valor);
                Adiciona(fila, 0, valor);
                break;
            case 2:
                printf("Digite um valor: ");
                scanf("%d", &valor);
                Adiciona(fila, 1, valor);
                break;
            case 3:
                Intercalar(fila);
                break;
            case 4:
                Imprimir(fila);
                break;
            case 5:
                printf("Programa finalizado!\n");
                break;
            default:
                printf("Opcao invalida!\n");
            break;
        }
    }while(op != 5);

    return 0;
}

void Inicia(Fila *f){
    for(int i=0; i < 3; i++){
        f[i].inicio = NULL;
        f[i].fim = NULL;
        f[i].tam = 0;
    }
}

int Menu(){
    int N;
    printf("\n[1]Adicionar na primeira fila\n[2]Adicionar na segunda fila\n[3]Intercalar\n[4]Imprimir\n[5]Sair\nEscolha: ");
    scanf("%d", &N);

    return N;
}

void Adiciona(Fila *f, int i, int valor){
    No *novo = malloc(sizeof(No));
    if(novo){
        novo->dado = valor;
        novo->prox = NULL;
        if(f[i].inicio == NULL){
            f[i].inicio = novo;
            f[i].fim = novo;
        }else{
            f[i].fim->prox = novo;
            f[i].fim = novo;
        }
        f[i].tam++;
    }else printf("Erro ao alocar memoria!\n");
}

void Reinicia(Fila *f, int i){
    No *end = f[i].inicio;
    while(end){
        No *apagar = end;
        end = end->prox;
        free(apagar);
    }
    f[i].inicio = NULL;
    f[i].fim = NULL;
    f[i].tam = 0;
}

void Intercalar(Fila *f){
    int A = f[0].tam, B = f[1].tam, i = 0, j = 0;
    No *endA = malloc(sizeof(No)), *endB = malloc(sizeof(No));
    endA = f[0].inicio;
    endB = f[1].inicio;
    Reinicia(f, 2);

    while(i<A && j<B){
        Adiciona(f, 2, endA->dado);
        endA = endA->prox;
        i++;

        Adiciona(f, 2, endB->dado);
        endB = endB->prox;
        j++;
    }

    while(i<A){
        Adiciona(f, 2, endA->dado);
        endA = endA->prox;
        i++;
    }
    while(j<B){
        Adiciona(f, 2, endB->dado);
        endB = endB->prox;
        j++;
    }
    printf("Filas intercaladas!\n");
}

void Imprimir(Fila *f){
    for(int i=0; i < 3; i++){
        printf("\nFILA %d:\n", i+1);
        No *end = f[i].inicio;
        while(end){
            printf("%d ", end->dado);
            end = end->prox;
        }
        printf("\nQuantidade: %d\n", f[i].tam);
    }
}