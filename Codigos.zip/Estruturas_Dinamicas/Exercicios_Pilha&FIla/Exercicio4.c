#include <stdio.h>
#include <stdlib.h>

typedef struct aux{
    char dado;
    struct aux *prox;
} No;

typedef struct{
    No *inicio;
    int tam;
} Pilha;

void Inicia(Pilha *p);
void Push(Pilha *p, char txt);
void Print(Pilha *p);
void Palindromo(Pilha *p);

int main(){
    Pilha *pilha = malloc(sizeof(Pilha));
    char txt;
    Inicia(pilha);

    printf("Escreva: ");
    do{
        scanf("%c", &txt);
        Push(pilha, txt);
    }while(txt != '\n');

    Print(pilha);
    Palindromo(pilha);

    return 0;
}

void Inicia(Pilha *p){
    p->inicio = NULL;
    p->tam = 0;
}

void Push(Pilha *p, char txt){
    No *novo = malloc(sizeof(No));

    if(novo){
        novo->dado = txt;
        novo->prox = p->inicio;
        p->inicio = novo;
        p->tam++;
    }else printf("Erro ao alocar memoria!\n");
}

void Print(Pilha *p){
    No *end = p->inicio;

    printf("Texto invertido: ");
    while(end){
        printf("%c", end->dado);
        end = end->prox;
    }
    printf("\nTamanho: %d\n", p->tam - 1);
}

void Palindromo(Pilha *p){
    char *txt = malloc(sizeof(p->tam));
    No *end = p->inicio;

    for(int i=0; i < p->tam; i++){
        txt[i] = end->dado;
        end = end->prox;
    }

    int size = p->tam - 1, teste = 0;
    for(int i=0; i <= size/2; i++){
        if(txt[i+1] != txt[size-i]) teste++;
    }

    if(teste==0) printf("Eh palindromo!\n");
    else printf("NAO eh palindromo!\n");
}