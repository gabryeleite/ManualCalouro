#include <stdio.h>
#include <stdlib.h>

typedef struct aux{
    int dado;
    struct aux *prox;
} No;

typedef struct{
    No *inicio;
    int tam;
} Lista;

void Inicia(Lista *l);
int Menu();
int Dado();
void InserirInicio(Lista *l);
void InserirFim(Lista *l);
void InserirMeio(Lista *l);
void InserirOrdem(Lista *l);
void Imprimir(Lista *l);
void Remover(Lista *l);
void Busca(Lista *l);

int main()
{
    Lista *lista = malloc(sizeof(Lista));
    int op;
    Inicia(lista);

    do{
        op = Menu();
        switch(op){
            case 1:
                InserirInicio(lista);
                break;
            case 2:
                InserirFim(lista);
                break;
            case 3:
                InserirMeio(lista);
                break;
            case 4:
                InserirOrdem(lista);
                break;
            case 5:
                Imprimir(lista);
                break;
            case 6:
                Remover(lista);
                break;
            case 7:
                Busca(lista);
                break;
            case 8:
                printf("Programa finalizado!\n");
            default:
                printf("Opcao Invalida!\n");
            break;
        }
    }while(op != 8);

    return 0;
}

void Inicia(Lista *l){
    l->inicio = NULL;
    l->tam = 0;
}

int Menu(){
    int N;
    printf("\n[1]Inserir Inicio\n[2]Inserir Fim\n[3]Inserir Meio\n[4]Inserir Ordenado\n[5]Imprimir Lista\n[6]Remover Elemento\n[7]Buscar Elemento\n[8]Sair\nEscolha: ");
    scanf("%d", &N);

    return N;
}

int Dado(){
    int N;
    printf("Digite um valor: ");
    scanf("%d", &N);

    return N;
}

void InserirInicio(Lista *l){
    No *novo = malloc(sizeof(No));
    if(novo){
        novo->dado = Dado();
        novo->prox = l->inicio;
        l->inicio = novo;
        l->tam++;
        printf("Elemento inserido com sucesso!\n");
    }else printf("Erro ao alocar memoria!\n");
}

void InserirFim(Lista *l){
    No *novo = malloc(sizeof(No));
    if(novo){
        novo->dado = Dado();
        novo->prox = NULL;
        if(l->inicio == NULL){
            l->inicio = novo;
        }else{
            No *aux = l->inicio;
            while(aux->prox){
                aux = aux->prox;
            }
            aux->prox = novo;
        }
        l->tam++;
        printf("Elemento inserido com sucesso!\n");
    }else printf("Erro ao alocar memoria!\n");
}

void InserirMeio(Lista *l){
    No *novo = malloc(sizeof(No));
    if(novo){
        novo->dado = Dado();
        if(l->inicio == NULL){
            novo->prox  = NULL;
            l->inicio = novo;
        }else{
            No *aux = l->inicio;
            int anterior;
            printf("Inserir apos o elemento: ");
            scanf("%d", &anterior);
            while(aux->dado != anterior && aux->prox){
                aux = aux->prox;
            }
            if(aux->prox == NULL) printf("O elemento sera inserido no final!\n");
            novo->prox = aux->prox;
            aux->prox = novo;
        }
        l->tam++;
        printf("Elemento inserido com sucesso!\n");
    }else printf("Erro ao alocar memoria!\n");
}

void InserirOrdem(Lista *l){
    No *novo = malloc(sizeof(No));
    if(novo){
        novo->dado = Dado();
        if(l->inicio == NULL){
            novo->prox = NULL;
            l->inicio = novo;
        }else if(novo->dado < l->inicio->dado){
            novo->prox = l->inicio;
            l->inicio = novo;
        }else{
            No *aux = l->inicio;
            while(aux->prox && novo->dado > aux->prox->dado){
                aux = aux->prox;
            }
            novo->prox = aux->prox;
            aux->prox = novo;
        }
        l->tam++;
        printf("Elemento inserido com sucesso!\n");
    }else printf("Erro ao alocar memoria!\n");
}

void Imprimir(Lista *l){
    No *end = l->inicio;
    printf("Lista:\n");
    while(end){
        printf("%d ", end->dado);
        end = end->prox;
    }
    printf("\nTamanho: %d\n", l->tam);
}

void Remover(Lista *l){
    No *aux = NULL;
    if(l->inicio){
        int N;
        printf("Digite o valor que queira remover: ");
        scanf("%d", &N);
        if(l->inicio->dado == N){
            No *apagar = aux;
            aux = l->inicio;
            l->inicio = aux->prox;
            l->tam--;
            free(apagar);
        }else{
            aux = l->inicio;
            while(aux->prox && aux->prox->dado != N){
                aux = aux->prox;
            }
            if(aux->prox){
                No *apagar = aux->prox;
                aux->prox = apagar->prox;
                l->tam--;
                free(apagar);
            }else printf("Elemento nao encontrado!\n");
        }
        printf("Elemento removido com sucesso: %d\n", N);
    }else printf("Lista esta vazia!\n");
}

void Busca(Lista *l){
    No *aux = l->inicio;
    int N = Dado();
    while(aux && aux->dado != N){
        aux  = aux->prox;
    }
    if(aux) printf("Elemento encontrado: %d\n", aux->dado);
    else printf("Elemento nao encontrado!\n");
}