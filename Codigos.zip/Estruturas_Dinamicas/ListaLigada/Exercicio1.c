#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef int Chave;

typedef struct{
    Chave chave;
} Registro;

typedef struct aux{
    Registro reg;
    struct aux* prox;
} Elemento;

typedef Elemento* Pont;

typedef struct{
    Pont inicio;
} Lista;

int Menu();
void Inicializar(Lista *l);
int Quantidade(Lista *l);
void Print(Lista *l);
int Busca(Lista *l);
Pont BuscaAux(Lista *l, Chave chave, Pont* ant);
bool Inserir(Lista *l);
bool Excluir(Lista *l);
void Reinicializar(Lista *l);
void Inverte(Lista *l);

int main()
{
    Lista *lista = malloc(sizeof(Lista));
    int op, size, busca;
    bool teste;
    
    do{
        op = Menu();
        switch(op){
        case 1:
            Inicializar(lista);
            break;
        case 2:
            size = Quantidade(lista);
            printf("Quantide de elementos da estrutura: %d\n", size);
            break;
        case 3:
            Print(lista);
            break;
        case 4:
            busca = Busca(lista);
            if(busca==0) printf("Elemento nao encontrado!\n");
            else printf("Elemento encontrado na posicao: %d\n", busca);
            break;
        case 5:
            teste = Inserir(lista);
            if(teste==false) printf("Nao foi possivel inserir o elemento na lista!\n");
            else printf("Elemento inserido com sucesso!\n");
            break;
        case 6:
            Excluir(lista);
            if(teste==false) printf("Nao foi possivel excluir o elemento na lista!\n");
            else printf("Elemento excluido com sucesso!\n");
            break;
        case 7:
            Reinicializar(lista);
            break;
        case 8:
            printf("Selecao Finalizada!\n");
            Inverte(lista);
            Print(lista);
            break;
        default:
            printf("Opcao Invalida!\nTente novamente.\n");
            break;
        }
    }while(op!=8);

    return 0;
}
int Menu(){
    int N;
    printf("\n[1]Inicializar estrutura\n[2]Quantidade de elementos\n[3]Exibir elementos\n[4]Buscar por elemento\n[5]Inserir elemento\n[6]Excluir elemento\n[7]Reinicializar estrutura\n[8]Finalizar e Inverter estrutura\nEscolha: ");
    scanf("%d", &N);
    return N;
}
void Inicializar(Lista* l){
    l->inicio = NULL;
    printf("Estrutura incializada!\n");
}
int Quantidade(Lista *l){
    Pont end = l->inicio;
    int size = 0;
    while(end!=NULL){
        size++;
        end = end->prox;
    }
    return size;
}
void Print(Lista *l){
    Pont end = l->inicio;
    int cont = 0;
    while(end!=NULL){
        printf("Elemento %d: %d\n", cont+1, end->reg.chave);
        cont++;
        end = end->prox;
    }
}
int Busca(Lista *l){
    Pont pos = l->inicio;
    Chave chave;
    printf("Digite o elemento que quer buscar: ");
    scanf("%d", &chave);
    int posicao = 1;
    while(pos!=NULL){
        if(pos->reg.chave==chave) return posicao;
        posicao++;
        pos = pos->prox;
    }
    return 0;
}
Pont BuscaAux(Lista *l, Chave chave, Pont* ant){
    *ant = NULL;
    Pont atual = l->inicio;
    while((atual!=NULL) && (atual->reg.chave < chave)){
        *ant = atual;
        atual = atual->prox;
    }
    if((atual!=NULL) && (atual->reg.chave==chave)) return atual;
    return NULL;
}
bool Inserir(Lista *l){
    Registro reg;
    printf("Digite elemento a ser inserido: ");
    scanf("%d", &reg.chave);
    Pont ant, novo;
    novo = BuscaAux(l, reg.chave, &ant);
    if(novo!=NULL) return false;
    novo = (Pont) malloc(sizeof(Elemento));
    novo->reg = reg;
    if(ant==NULL){
        novo->prox = l->inicio;
        l->inicio = novo;
    }else{
        novo->prox = ant->prox;
        ant->prox = novo;
    }
    return true;
}
bool Excluir(Lista *l){
    Chave chave;
    printf("Digite elemento a ser excluido: ");
    scanf("%d", &chave);
    Pont ant, i;
    i = BuscaAux(l, chave, &ant);
    if(i==NULL) return false;
    if(ant==NULL) l->inicio = i->prox;
    else ant->prox = i->prox;
    free(i);
    return true;
}
void Reinicializar(Lista *l){
    Pont end = l->inicio;
    while(end!=NULL){
        Pont apagar = end;
        end = end->prox;
        free(apagar);
    }
    l->inicio = NULL;
    printf("Estrutura Reinicializada!\n");
}
void Inverte(Lista *l){
    Pont end, atual = l->inicio;
    Pont ant = NULL;
    while(atual!=NULL){
        end = atual->prox;
        atual->prox = ant;
        ant = atual;
        atual = end;
    }
    l->inicio = ant;
    printf("Lista Invertida: \n");
}