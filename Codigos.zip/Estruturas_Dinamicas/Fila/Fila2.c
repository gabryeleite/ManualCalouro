#include <stdio.h>
#include <stdlib.h>

typedef struct aux{
    int dado;
    struct aux *prox;
} No;

typedef struct{
    No *inicio;
    No *fim; //Nao precisa percorrer a fila inteira
    int tam;
} Fila;

int Menu();
void Inicia(Fila *f);
void Inserir(Fila *f);
void Remover(Fila *f);
void Imprimir(Fila *f);
void Reiniciar(Fila *f);

int main()
{
    Fila *fila = malloc(sizeof(Fila));
    int op;

    do{
        op = Menu();
        switch(op){
            case 1:
                Inicia(fila);
                break;
            case 2:
                Inserir(fila);
                break;
            case 3:
                Remover(fila);
                break;
            case 4:
                Imprimir(fila);
                break;
            case 5:
                Reiniciar(fila);
                break;
            case 6:
                printf("Programa finalizado!\n");
                break;
            default:
                printf("Opcao invalida!\n");
            break;
        }
    }while(op != 6);

    return 0;
}

int Menu(){
    int N;
    printf("\n[1]Iniciar\n[2]Inserir\n[3]Remover\n[4]Imprimir\n[5]Reiniciar\n[6]Sair\nEscolha: ");
    scanf("%d", &N);

    return N;
}

void Inicia(Fila *f){
    f->inicio = NULL;
    f->fim = NULL;
    f->tam = 0;
    printf("Fila inicializada!\n");
}

void Inserir(Fila *f){
    No *novo = malloc(sizeof(No));
    if(novo){
        printf("Digite um valor: ");
        scanf("%d", &novo->dado);
        novo->prox = NULL;
        if(f->inicio == NULL){ //Ocorre na primeira vez quando a fila esta vazia
            f->inicio = novo;
            f->fim = novo;
        }else{
            f->fim->prox = novo;
            f->fim = novo;
        }
        f->tam++;
        printf("Elemento inserido com sucesso!\n");
    }else printf("Erro ao alocar memoria!\n");
}

void Remover(Fila *f){
    No *end = NULL;
    if(f->inicio){
        No *apagar = end;
        end = f->inicio;
        f->inicio = end->prox; 
        printf("Valor removido: %d\n", end->dado);
        f->tam--;
        free(apagar);
    }else printf("Fila vazia!\n");
}

void Imprimir(Fila *f){
    No *end = f->inicio;
    while(end){
        printf("%d ", end->dado);
        end = end->prox;
    }
    printf("\nQuantidade: %d\n", f->tam);
}

void Reiniciar(Fila *f){
    No *end = f->inicio;
    while(end){
        No *apagar = end;
        end = end->prox;
        free(apagar);
    }
    f->inicio = NULL;
    f->fim = NULL;
    f->tam = 0;
}