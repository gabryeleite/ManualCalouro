#include <stdio.h>

int main()
{
    int N;
    float soma=0;

    for(int i=0; i<10; i++){
        printf("Digite o %d.o numero: ", i+1);
        scanf("%d", &N);
        soma += N;
    }
    printf("Media = %.2f", soma/10.0);

    return 0;
}