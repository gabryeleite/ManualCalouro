#include <stdio.h>

int main()
{
    int N, cont=1;

    printf("Digite um numero: ");
    scanf("%d", &N);
    for(int i=0; i<=N; i++){
        for(int j=0; j<i; j++){
            printf("%d ", cont);
            cont++;
        }
        printf("\n");
    }

    return 0;
}