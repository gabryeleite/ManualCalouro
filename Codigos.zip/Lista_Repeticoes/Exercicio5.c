#include <stdio.h>

int main()
{
    int a, b, x, y, soma = 0;

    for(int i=0; i<20; i++){
        printf("Digite dois numeros: ");
        scanf("%d%d", &a, &b);
        if(a>b){
            y=a; 
            x=b;
        } 
        else{
            y=b; 
            x=a;
        } 
        while(x<=y){
            soma += x;
            x++;
        }
        printf("%d\n", soma);
        soma = 0;
    }

    return 0;
}