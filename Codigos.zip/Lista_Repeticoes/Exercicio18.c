#include <stdio.h>

int main()
{
    int N, a=0, b=0, c=0, d=0;

    printf("Digite um numero[Nao negativo]: ");
    scanf("%d", &N);
    while(N>=0){
        if(N<=25) a++;
        else if(N<=50) b++;
        else if(N<=75) c++;
        else if(N<=100) d++;
        printf("Digite outro numero: ");
        scanf("%d", &N);
    }
    printf("Quantida de Numeros nos intervalos:\n[0-25]: %d\n[26-50]: %d\n[51-75]: %d\n[76-100]: %d\n", a, b, c, d);

    return 0;
}