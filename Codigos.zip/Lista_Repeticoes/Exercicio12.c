#include <stdio.h>

int main()
{
    int N, maior, cont=0;
    
    printf("Digite a quantidade: ");
    scanf("%d", &N);
    int num[N];

    for(int i=0; i<N; i++){
        printf("Digite o %d.o numero: ", i+1);
        scanf("%d", &num[i]);
        if(i==0) maior = num[i];
        if(num[i]>maior) maior = num[i];
    }
    printf("\nMaior = %d\n", maior);

    for(int i=0; i<N; i++){
        if(num[i]==maior) cont++;
    }
    printf("%d foi lido %d vezes\n", maior, cont);

    return 0;
}