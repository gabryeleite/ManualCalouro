#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int N, sorteado;

    srand((unsigned)time(NULL));
    sorteado = rand() % 100;

    printf("TESTE\nNumero sorteado = %d\n\n", sorteado);
    printf("Digite um numero: ");
    scanf("%d", &N);
    while(N!=sorteado){
        if(sorteado>N) printf("Muito baixo\n");
        else if (sorteado<N) printf("Muito alto\n");
        printf("Digite outro numero: ");
        scanf("%d", &N);
    }
    printf("ACERTOU!\n");

    return 0;
}