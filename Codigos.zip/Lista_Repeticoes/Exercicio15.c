#include <stdio.h>
#include <math.h>

int main()
{
    float N[10], soma=0, media, desvio, somatorio=0;

    for(int i=0; i<10; i++){
        printf("Digite o %d.o numero: ", i+1);
        scanf("%f", &N[i]);
        soma += N[i];
    }
    media = soma/10.0;

    for(int i=0; i<10; i++){
        somatorio += pow((N[i]-media),2);
    }

    desvio = sqrt(somatorio/9.0);
    printf("\nMedia = %.2f\nDesvio = %.5f\n", media, desvio);

    return 0;
}   
