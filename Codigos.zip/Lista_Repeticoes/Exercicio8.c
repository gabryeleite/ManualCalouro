#include <stdio.h>
#include <math.h>

int main()
{
    int num;

    printf("Digite um numero: ");
    scanf("%d", &num);
    while(num>0){
        if(num%2==0) printf("%d\n", num*num);
        else printf("%.2f\n", sqrt(num));
        printf("Digite outro numero: ");
        scanf("%d", &num);
    }

    return 0;
}