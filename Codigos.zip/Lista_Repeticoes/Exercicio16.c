#include <stdio.h>

int main()
{
    int N, A=0, B=1, C;

    printf("Digite um numero: ");
    scanf("%d", &N);
    if(N==1) printf("0\n");
    else if(N==2) printf("1\n");
    else{
        for(int i=0; i<N-2; i++){
            C = A + B;
            A = B;
            B = C;
            if(i==N-3) printf("%d ", C);
        }
        printf("\n");
    }

    return 0;
}