#include <stdio.h>

int main()
{
    int quantidade;
    float preco, total;

    printf("Digite preco do produto: ");
    scanf("%f", &preco);
    printf("Digite a quantidade: ");
    scanf("%d", &quantidade);
    printf("%.2f\n", preco*quantidade);

    return 0;
}