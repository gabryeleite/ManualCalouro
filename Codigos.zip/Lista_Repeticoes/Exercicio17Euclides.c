#include <stdio.h>
#include <math.h>

int Primo(int N);

int main()
{
    int N=1, cont=0, primo;
    double perfeito; //Com a formula de Euclides programa roda mais rapido.

    while(cont<5){
        primo = Primo(pow(2,N)-1);
        if(primo==1){
            perfeito = (pow(2,N)-1)*pow(2,N-1);
            printf("%.0lf\n", perfeito);
            cont++;
        }
        N++;
    }

    return 0;
}
int Primo(int N){
    int teste=0;

    for(int i=1; i<N; i++){
        if(N%i==0) teste++;
    }
    if(teste==1) return 1;
    else return 0;
}