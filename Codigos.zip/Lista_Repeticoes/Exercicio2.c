#include <stdio.h>

int main()
{
    int ano;

    printf("Digite o ano em que nasceu: ");
    scanf("%d", &ano);
    printf("%d\n", 2023-ano);

    return 0;
}