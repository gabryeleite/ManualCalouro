#include <stdio.h>

int main()
{
    int num, maior, menor;

    for(int i=0; i<10; i++){
        printf("Digite um numero: ");
        scanf("%d", &num);
        if(i==0){
            maior = num;
            menor = num;
        }
        if(num>maior) maior = num;
        if(num<menor) menor = num;
    }
    printf("Maior: %d\n", maior);
    printf("Menor: %d\n", menor);

    return 0;
}