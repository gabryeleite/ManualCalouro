#include <stdio.h>
 
int main() 
{
    int num, fatorial = 1;

    for(int i=0; i<20; i++){
        printf("Digite um numero: ");
        scanf("%d", &num);
        if(num==0) printf("1\n");
        else{
            for(int j=1; j<=num; j++){
                fatorial = fatorial*j;
            }
            printf("%d\n", fatorial);
        }
        fatorial = 1;
    }

    return 0;
}