#include <stdio.h>

int main()
{
    float valor;
    
    printf("Digite o valor da compra: ");
    scanf("%f", &valor);
    if(valor < 100) printf("Sem desconto\nValor final: %.2f\n", valor);
    else if(valor <=200) printf("5%% de desconto\nValor final: %.2f", valor-valor*0.05);
    else if(valor <=300) printf("10%% de desconto\nValor final: %.2f", valor-valor*0.10);
    else printf("15%% de desconto\nValor final: %.2f", valor-valor*0.15);

    return 0;
}