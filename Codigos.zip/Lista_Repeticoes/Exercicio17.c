#include <stdio.h>

int main()
{
    int N=2, cont=0, soma=0;

    while(cont<4){ //Deixei ate 4 pq meu computador estava demorando para rodar ate o 5°.
        for(int i=1; i<N; i++){
            if(N%i==0) soma += i;
        } 
        if(soma==N){
            printf("%d\n", N);
            cont++;
        }
        N++;
        soma = 0;
    }

    return 0;
}