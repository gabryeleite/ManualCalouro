#include <stdio.h>

int main()
{
    int a, b;

    printf("Digite dois numeros: ");
    scanf("%d%d", &a, &b);
    if(a==b) printf("%d\n", a*a);
    else if(a>b) printf("%d\n", a+b);
    else printf("%d\n", b-a);

    return 0;
}