#include <stdio.h>

int main()
{
    int num, par = 0;
    float impar, soma = 0;

    for(int i=0; i<10; i++){
        printf("Digite um numero: ");
        scanf("%d", &num);
        if(num%2==0) par++;
        else soma += num;
        impar = 10-par;
    }
    printf("Quantidade de pares: %d\n", par);
    printf("Media dos impares: %.2f\n", soma/impar);

    return 0;
}