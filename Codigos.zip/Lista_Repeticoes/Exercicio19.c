#include <stdio.h>

int main()
{
    int n, m, soma=0;

    printf("Digite dois numeros: ");
    scanf("%d%d", &n, &m);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=m; j++){
            soma += i+j;
        }   
    }
    printf("Soma = %d", soma);

    return 0;
}