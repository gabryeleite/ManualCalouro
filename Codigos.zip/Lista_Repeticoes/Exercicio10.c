#include <stdio.h>
 
int main() 
{
    int num, soma = 0, divisores = 0;

    for(int i=0; i<10; i++){
        printf("Digite um numero: ");
        scanf("%d", &num);
        for(int j=1; j<=num; j++){
            if(num%j==0) divisores++;
            soma += j;
        }
        printf("Numero de divisores: %d\n", divisores);
        printf("Soma de 1 ate %d = %d\n\n", num, soma);
        divisores = 0;
        soma = 0;
    }

    return 0;
}