#include <stdio.h>
#include <stdlib.h>

int* Leitura(int N);

int main()
{
    int N;

    printf("Digite tamanho: ");
    scanf("%d", &N);

    int *p = Leitura(N);

    if(p==NULL) printf("Memoria Insuficiente!\nPonteiro nulo.\n");
    else printf("Memoria suficiente!\nPonteiro nao nulo.\n");

    free(p);

    return 0;
}
int* Leitura(int N){
    int *p;
    if(N>0) p = calloc(N, sizeof(int));
    else p = NULL;
    return p;
}