#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int** Leitura(int lin, int col);
void Impressao(int **p, int lin, int col);
int Verificar(int **p, int valor, int lin, int col);


int main()
{
    int N, lin, col;
    srand(time(NULL));

    printf("Digite linha e coluna: ");
    scanf("%d%d", &lin, &col);

    int **p = Leitura(lin, col);
    if(p==NULL) return 1;
    Impressao(p, lin, col); //Imprimo a matriz antes para verificar se o programa esta funcioando corretamente

    printf("Digite um valor: ");
    scanf("%d", &N);

    int teste = Verificar(p, N, lin, col);
    if(teste==1) printf("O numero %d escontra-se na matriz\n", N);
    else printf("O numero %d NAO escontra-se na matriz\n", N);

    for(int i=0; i<lin; i++) free(p[i]);
    free(p);

    return 0;
}
int** Leitura(int lin, int col){
    int **p = malloc(lin*sizeof(int *));
    for(int i=0; i<lin; i++) p[i] = calloc(col, sizeof(int));
    if(p==NULL) printf("Erro. Memoria Insuficiente!\n");
    else{
        for(int i=0; i<lin; i++){
            for(int j=0; j<col; j++){
                p[i][j] = rand() % 100; //atribuir valores aleatorios para a matriz
            }
        }
    }
    return p;
}
void Impressao(int **p, int lin, int col){
    printf("Matriz: \n");
    for(int i=0; i<lin; i++){
        for(int j=0; j<col; j++){
            printf("%3d", p[i][j]);
        }
        printf("\n");
    }
}
int Verificar(int **p, int valor, int lin, int col){
    int teste = 0;
    for(int i=0; i<lin; i++){
        for(int j=0; j<col; j++){
            if(p[i][j]==valor) teste = 1;
        }
    }
    return teste;
}