#include <stdio.h>
#include <stdlib.h>

int* Leitura(int N, int valor);
void Impressao(int *p, int N);

int main()
{
    int N, valor;
    
    printf("Digite tamanho e um valor: ");
    scanf("%d%d", &N, &valor);

    int *p = Leitura(N, valor);
    if(p==NULL) return 1;
    Impressao(p, N);

    free(p);

    return 0;
}
int* Leitura(int N, int valor){
    int *p = calloc(N, sizeof(int));
    if(N>0) for(int i=0; i<N; i++) p[i] = valor;
    else{
        p = NULL;
        printf("Erro. Memoria Insuficiente!\n");
    } 
    return p;
}
void Impressao(int *p, int N){
    printf("Vetor: \n");
    for(int i=0; i<N; i++) printf("%d ", p[i]);
}