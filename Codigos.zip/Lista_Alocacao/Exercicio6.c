#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* Inverte(char *p, int N);

int main()
{
    char str[40];
    printf("Escreva string: ");
    scanf(" %[^\n]", str);
    int size = strlen(str);

    char *p = Inverte(str, size);
    printf("String Invertida: \n%s\n", p);
    free(p);

    return 0;
}
char* Inverte(char *p, int N){
    char *str = malloc(N*sizeof(char));
    for(int i=0; i<N; i++) str[i] = p[N-i-1];
    str[N] = '\0';
    return str;
}