#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int** Leitura(int la, int ca, int lb, int cb, int A[la][ca], int B[lb][cb]);
void Scan(int lin, int col, int M[lin][col]);
void Print(int lin, int col, int M[lin][col]);
void Impressao(int **p, int lin, int col);

int main()
{
    int linA, colA, linB, colB;
    srand(time(NULL));

    printf("Digite linha e coluna da Matriz A: ");
    scanf("%d%d", &linA, &colA);
    printf("Digite linha e coluna da Matriz B: ");
    scanf("%d%d", &linB, &colB);

    int A[linA][colA], B[linB][colB];

    int **C = Leitura(linA, colA, linB, colB, A, B);
    if(C==NULL) return 1;

    Impressao(C, linA, colB);

    for(int i=0; i<linA; i++) free(C[i]);
    free(C);

    return 0;
}
int** Leitura(int la, int ca, int lb, int cb, int A[la][ca], int B[lb][cb]){
    int **C;
    if(ca!=lb){
        C = NULL;
        printf("Erro. Ponteiro nulo!");
    }else{
        C = malloc(la*sizeof(int *));
        for(int i=0; i<la; i++) C[i] = calloc(cb,sizeof(int));

        Scan(la, ca, A);
        Scan(lb, cb, B);
        printf("Matriz A: \n");
        Print(la, ca, A);
        printf("Matriz B: \n");
        Print(lb, cb, B);

        for(int i=0; i<la; i++){
            for(int j=0; j<cb; j++){
                C[i][j] = 0;
                for(int k=0; k<lb; k++){
                    C[i][j] += A[i][k] * B[k][j];
                }
            }
        }
    }
    return C;
}
void Scan(int lin, int col, int M[lin][col]){
    for(int i=0; i<lin; i++){
        for(int j=0; j<col; j++){
            M[i][j] = rand() % 10;
        }
    }
}
void Print(int lin, int col, int M[lin][col]){
    for(int i=0; i<lin; i++){
        for(int j=0; j<col; j++){
            printf("%2d ", M[i][j]);
        }
        printf("\n");
    }
}
void Impressao(int **p, int lin, int col){
    printf("Matriz C: \n");
    for(int i=0; i<lin; i++){
        for(int j=0; j<col; j++){
            printf("%2d ", p[i][j]);
        }
        printf("\n");
    }
}