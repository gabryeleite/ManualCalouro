#include <stdio.h>
#include <stdlib.h>

typedef struct{
    char nome[40];
    int idade;
    char adress[100];
} cadastro;

cadastro* Leitura(int N);
void Impressao(cadastro *p, int N);

int main()
{
    int N;

    printf("Digite tamanho: ");
    scanf("%d", &N);

    cadastro *p = Leitura(N);
    if(p==NULL) return 1;
    Impressao(p, N);

    free(p);

    return 0;
}
cadastro* Leitura(int N){
    cadastro *p = malloc(N*sizeof(cadastro));

    if(p==NULL) printf("Erro. Memoria Insuficiente!\n");
    else{
        for(int i=0; i<N; i++){
            printf("\nCADASTRO %d\n", i+1);
            printf("Nome: ");
            scanf(" %[^\n]", p[i].nome);
            printf("Idade: ");
            scanf("%d", &p[i].idade);
            printf("Endereco: ");
            scanf(" %[^\n]", p[i].adress);
        }
    }
    return p;
}
void Impressao(cadastro *p, int N){
    printf("RELATORIO CADASTRO(S)\n");
    for(int i=0; i<N; i++){
        printf("CADASTRO %d\n", i+1);
        printf("Nome: %s\n", p[i].nome);
        printf("Idade: %d\n", p[i].idade);
        printf("Endereco: %s\n", p[i].adress);
        printf("\n");
    }
}