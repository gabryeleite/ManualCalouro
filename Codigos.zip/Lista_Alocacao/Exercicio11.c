#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int* Sorteio();
int* Aposta();
void Compare(int *sorteio, int *apostado);
void Print(int *p, int N);

int main()
{
    srand(time(NULL));

   int *sorteio = Sorteio();
   int *apostado = Aposta();
   Compare(sorteio, apostado);

   free(sorteio);
   free(apostado);

    return 0;
}
int* Sorteio(){
    int *sorteio = calloc(6,sizeof(int));
    for(int i=0; i<6; i++) sorteio[i] = rand() % 60;
    
    return sorteio;
}
int* Aposta(){
    int *apostado = calloc(6,sizeof(int));
    for(int i=0; i<6; i++){
        printf("Digite %d.0 numero: ", i+1);
        scanf("%d", &apostado[i]);
    }
    return apostado;
}
void Compare(int *sorteio, int *apostado){
    int *acerto = calloc(6,sizeof(int));
    int k=0;
    for(int i=0; i<6; i++){
        for(int j=0; j<6; j++){
            if(sorteio[i]==apostado[j]){
                acerto[k] = apostado[j];
                k++;
                break;
            }
        }
    }
    printf("Numeros sorteados: \n");
    Print(sorteio, 6);
    printf("\nNumeros acertados: \n");
    Print(acerto, k);
    free(acerto);
} 
void Print(int *p, int N){
    for(int i=0; i<N; i++) printf("%d ", p[i]);
}