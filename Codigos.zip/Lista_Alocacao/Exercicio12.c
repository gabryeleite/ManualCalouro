#include <stdio.h>
#include <stdlib.h>

int* Memory(int N);

int main() {
    int N;
    printf("Digite tamanho da memoria(bytes): ");
    scanf("%d", &N);

    int *memory = Memory(N);
    if(memory==NULL) return 1;

    free(memory);

    return 0;
}
int* Memory(int N){
    int* p = calloc(N,sizeof(int));

    if(p==NULL) printf("Erro. Memoria indisponivel!\n");
    else{
        int num, end, dado;
        while(1){
            printf("\n[1]Inserir dado em endereco\n[2]Consultar dado de um endereco\nDigite: ");
            scanf("%d", &num);
            if(num==1){
                do{
                printf("Digite endereco (0 a %d): ", N-1);
                scanf("%d", &end);
                if(end<0 || end>=N) printf("Endereco invalido!\nTente novamente.\n");
                }while(end<0 || end>=N);
                printf("Digite dado: ");
                scanf("%d", &dado);
                p[end] = dado;
                printf("%d foi alocado em %d!\n", dado, end);
            }else if(num==2){
                do{
                printf("Digite endereco (0 a %d): ", N-1);
                scanf("%d", &end);
                if(end<0 || end>=N) printf("Endereco invalido!\nTente novamente.\n");
                }while(end<0 || end>=N);
                printf("Dado de %d: %d\n", end, p[end]);
            }else printf("Opcao invalida!\nTente novamente.\n");
        }
    }
    return p;
}