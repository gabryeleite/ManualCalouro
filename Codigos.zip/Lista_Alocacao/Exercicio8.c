#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int N;

int* Leitura(int A[N][N], int tam);
void Impressao(int *p, int tam);

int main()
{
    srand(time(NULL));

    printf("Digite tamanho: ");
    scanf("%d", &N);
    int A[N][N];

    int *B = Leitura(A, N);
    if(B==NULL) return 1;
    Impressao(B, N);

    free(B);

    return 0;
}
int* Leitura(int A[N][N], int tam){
    int soma = 0;
    int *B = calloc(tam, sizeof(int));
    if(B==NULL) printf("Erro. Memoria Insuficiente!\n");
    else{
        printf("Matriz: \n");
        for(int i=0; i<tam; i++){
            for(int j=0; j<tam; j++){
                A[i][j] = rand() % 100; //atribuir valores aleatorios para a matriz
                soma += A[i][j];
                printf("%3d", A[i][j]);
            }
            B[i] = soma;
            soma = 0;
            printf("\n");
        }
    }
    return B;
}
void Impressao(int *p, int tam){
    printf("Soma das linhas da Matriz: \n");
    for(int i=0; i<tam; i++){
        printf("Linha %d: %d\n", i+1, p[i]);
    }
}