#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int cod;
    char nome[50];
    int quantidade;
    float preco;
} produto;

produto* Leitura(int N);

int main()
{
    int N;

    printf("Digite quantidade: ");
    scanf("%d", &N);
    produto *p = Leitura(N);
    if(p==NULL) return 1;

    free(p);

    return 0;
}
produto* Leitura(int N){
    produto *p;
    if(N<=0){
        p = NULL;
        printf("Erro. Memoria Indisponivel!\n");
    }else{
        p = malloc(N*sizeof(produto));
        int estoque, a, b;
        float caro;
        for(int i=0; i<N; i++){
            printf("\nPRODUTO %d\n", i+1);
            printf("Codigo de Identificacao: ");
            scanf("%d", &p[i].cod);
            printf("Nome do produto: ");
            scanf(" %[^\n]", p[i].nome);
            printf("Quantidade disponivel: ");
            scanf("%d", &p[i].quantidade);
            printf("Preco: ");
            scanf("%f", &p[i].preco);
            if(i==0){
                caro = p[i].preco;
                estoque = p[i].quantidade;
                a = i;
                b = i;
            }else{
                if(p[i].preco>caro){
                    caro = p[i].preco;
                    a = i;
                } 
                if(p[i].quantidade>estoque){
                    estoque = p[i].quantidade;
                    b = i;
                } 
            }
        }
        printf("Produto com maior preco: %s\n", p[a].nome);
        printf("Produto com maior estoque: %s\n", p[b].nome);
    }
    return p;
}