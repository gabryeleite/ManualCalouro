#include <stdio.h>
#include <stdlib.h>

int* Leitura(int N);
void Impressao(int *p, int N);

int main()
{
    int N;

    printf("Digite tamanho: ");
    scanf("%d", &N);

    int *p = Leitura(N);
    if(p==NULL) return 1;
    Impressao(p, N);

    free(p);

    return 0;
}
int* Leitura(int N){
    int *p = calloc(N,sizeof(int));
    if(p==NULL) printf("Erro. Memoria Insuficiente!\n");
    else{
        for(int i=0; i<N; i++){
            printf("Digite %d.o valor: ", i+1);
            scanf("%d", &p[i]);
        }
    }
    return p;
}
void Impressao(int *p, int N){
    printf("Vetor: \n");
    for(int i=0; i<N; i++) printf("%d ", p[i]);
    printf("\n");
}