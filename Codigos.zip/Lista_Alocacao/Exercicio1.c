#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int matricula;
    char nome[40];
    int nota[3];
} dado;

int main()
{
    printf("Tamanho Struct: %d byte(s)\n", sizeof(dado));

    return 0;
}