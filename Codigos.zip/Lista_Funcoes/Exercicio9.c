#include <stdio.h>

float Media(int V[], int i);

int main()
{
    int N;

    printf("Digite tamanho do vetor: ");
    scanf("%d", &N);
    int V[N];

    for(int i=0; i<N; i++){
        printf("Digite %d.o valor: ", i+1);
        scanf("%d", &V[i]);
    } 
    printf("Media: %.2f\n", Media(V, N-1)/3.0);

    return 0;
}
float Media(int V[], int i){
    if(i==-1) return 0;
    else return (V[i] + Media(V, i-1));
}