#include <stdio.h>

float Harmonico(float n);

int main()
{
    float N;

    printf("Digite um numero: ");
    scanf("%f", &N);
    printf("Hn = %.3f\n", Harmonico(N));

    return 0;
}
float Harmonico(float n){
    if(n==1) return 1;
    else return (1.0/n + Harmonico(n-1));
}