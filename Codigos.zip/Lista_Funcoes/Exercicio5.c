#include <stdio.h>

void PrintTriangulo(int a);

int main()
{
    int N;

    printf("Digite um numero: ");
    scanf("%d", &N);
    PrintTriangulo(N);

    return 0;
}
void PrintTriangulo(int a){
    for(int i=1; i<=a; i++){
        for(int j=0; j<i; j++) printf("*");
        printf("\n");
    }
    for(int i=a-1; i>0; i--){
        for(int j=0; j<i; j++) printf("*");
        printf("\n");
    }
}