#include <stdio.h>

float Media(int a, int b, int c, char d);

int main()
{
    float N1, N2, N3;
    char tipo;
    
    printf("Digite tres notas: ");
    scanf("%f%f%f", &N1, &N2, &N3);
    printf("Escolha Media:\n[A]Aritmetica\n[P]Ponderada\n");
    scanf(" %c", &tipo);
    printf("Media: %.2f\n", Media(N1, N2, N3, tipo));

    return 0;
}
float Media(int a, int b, int c, char d){
    if(d=='A') return((a + b + c)/3.0);
    else return((5*a + 3*b + 2*c)/10.0);
}