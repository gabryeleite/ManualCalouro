#include <stdio.h>
#include <math.h>

float Fatorial(int n);
float Cos(float x);

int main()
{
    int N;
    float rad;

    printf("Digite angulo em graus: ");
    scanf("%d", &N);
    rad = (float)N*(3.1414592/180.0);
    printf("Cos(%d): %.3f\n", N, Cos(rad));

    return 0;
}
float Fatorial(int n){
    if(n==0) return 1;
    else return (n*Fatorial(n-1));
}
float Cos(float x){
    float num, den, soma=0;
    for(int i=0; i<5; i++){
        num = pow(x,2*i)*pow((-1),i);
        den = Fatorial(2*i);
        soma += (float)num/den;
    }
    return (soma);
}