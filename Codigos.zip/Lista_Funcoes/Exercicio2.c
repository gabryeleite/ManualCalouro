#include <stdio.h>

int Tempo(int h, int m, int s);

int main()
{
    int hora, min, seg;
    
    printf("Digite horas, minutos e segundos: ");
    scanf("%d%d%d", &hora, &min, &seg);
    printf("Tempo em segundos: %d", Tempo(hora, min, seg));

    return 0;
}
int Tempo(int h, int m, int s){
    return(h*3600 + m*60 + s);
}