#include <stdio.h>

int Inverte(int n, int aux);

int main()
{
    int N;

    printf("Digite um numero: ");
    scanf("%d", &N);
    printf("Numero invertido: %d", Inverte(N, 0));

    return 0;
}
int Inverte(int n, int aux){
    if(n==0) return aux;
    else{
        int num = n%10;
        aux = (aux*10) + num;
        return Inverte(n/10, aux);
    }
}