#include <stdio.h>

float Fatorial(int n);
float E(int n);

int main()
{
    int N;

    printf("Digite um numero: ");
    scanf("%d", &N);
    printf("E = %.3f\n", E(N));

    return 0;
}
float Fatorial(int n){
    if(n==0) return 1;
    else return (n*Fatorial(n-1));
}
float E(int n){
    float soma = 0;
    for(int i=0; i<=n; i++){
        soma += 1.0/Fatorial(i);
    }
    return soma;
}