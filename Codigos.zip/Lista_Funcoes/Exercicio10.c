#include <stdio.h>

float Power(int a, int b);

int main()
{
    int x, y;

    printf("Digite dois valores: ");
    scanf("%d%d", &x, &y);
    printf("x elevado a y = %.1f\n", Power(x, y));

    return 0;
}
float Power(int a, int b){
    if(b==0) return 1;
    else return(a*Power(a, b-1));
}