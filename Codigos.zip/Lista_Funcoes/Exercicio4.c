#include <stdio.h>

int Primo(int n);
int Fator(int a);

int main()
{
    int N;

    printf("Digite um numero: ");
    scanf("%d", &N);
    if(Primo(N)==0) printf("%d eh primo\n", N);
    else printf("%d nao eh primo\n", N);
    printf("Maior divisivel primo: %d\n", Fator(N));

    return 0;
}
int Primo(int n){
    int teste=0;
    for(int i=1; i<=n; i++){
        if(n%i==0) teste++;
    }
    if(teste==2) return 0;
    else return 1;
}
int Fator(int a){
    int primo;
    for(int i=1; i<=a; i++){
        if(a%i==0 && Primo(i)==0) primo = i; 
    } 
    return primo;    
}