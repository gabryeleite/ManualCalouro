#include <stdio.h>

int Menor(int V[], int i);

int main()
{
    int N;

    printf("Digite tamanho do vetor: ");
    scanf("%d", &N);
    int V[N];

    for(int i=0; i<N; i++){
        printf("Digite %d.o valor: ", i+1);
        scanf("%d", &V[i]);
    } 
    printf("Menor: %d\n", Menor(V, N-1));

    return 0;
}
int Menor(int V[], int i){
    if(i==0) return V[i];
    else{
        if(V[i] >= Menor(V, i-1)) V[i] = V[i-1];
        return V[i];
    } 
}