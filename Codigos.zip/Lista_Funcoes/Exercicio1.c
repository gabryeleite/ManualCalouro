#include <stdio.h>

float Volume(float h, float r);

int main()
{
    float h, raio;

    printf("Digite altura e raio: ");
    scanf("%f%f", &h, &raio);
    printf("Volume = %.3f\n", Volume(h, raio));

    return 0;
}
float Volume(float h, float r){
    return (h*r*r*3.1414592);
}