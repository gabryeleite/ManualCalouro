#include <stdio.h>

float Soma(float n);

int main()
{
    float N;

    printf("Digite um numero: ");
    scanf("%f", &N);
    printf("Soma: %.2f", Soma(N));

    return 0;
}
float Soma(float n){
    if(n==1) return 2;
    else return ((1 + n*n)/n + Soma(n-1));
}