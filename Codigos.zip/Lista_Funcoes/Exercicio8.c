#include <stdio.h>
#include <math.h>

float Cubo(int n);

int main()
{
    int N;

    printf("Digite um numero: ");
    scanf("%d", &N);
    printf("Soma dos primeiros %d cubos = %.2f\n", N, Cubo(N)-1);

    return 0;
}
float Cubo(int n){
    if(n==0) return 1;
    else return (pow(n,3) + Cubo(n-1));
}