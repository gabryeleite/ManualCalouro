#include <stdio.h>

int main()
{
    int A[5][5], soma = 0;

    for(int i=0; i<5; i++){
        for(int j=0; j<5; j++){
            printf("Digite [%d,%d]: ", i, j);
            scanf("%d", &A[i][j]);
        }
    }
    printf("Matriz\n");
    for(int i=0; i<5; i++){
        for(int j=0; j<5; j++){
            printf("%3d", A[i][j]);
            if(i<j) soma += A[i][j];
        }
        printf("\n");
    }

    printf("Soma acima diagonal principal: %d\n", soma);

    return 0;
}