#include <stdio.h>

int main()
{
    int A[3][3], V[3];

    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            printf("Digite [%d,%d]: ", i, j);
            scanf("%d", &A[i][j]);
        }
    }
    
    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            printf("%3d", A[i][j]);
        }
        printf("\n");
    }

    for(int i=0; i<3; i++){
        V[i] = 0;
        for(int j=0; j<3; j++){
            V[i] += A[j][i];
        }
        printf("Soma coluna %d: %d\n", i+1, V[i]);
    }

    return 0;
}