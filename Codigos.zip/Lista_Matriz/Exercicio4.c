#include <stdio.h>

int main()
{
    int A[3][3], soma = 0;

    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            printf("Digite [%d,%d]: ", i, j);
            scanf("%d", &A[i][j]);
            if(i==j) soma += A[i][j];
        }
    }
    
    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            printf("%3d", A[i][j]);
        }
        printf("\n");
    }
    printf("Soma da diagonal principal: %d\n", soma);

    return 0;
}