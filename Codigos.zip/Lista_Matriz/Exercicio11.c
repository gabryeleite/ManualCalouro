#include <stdio.h>

int main()
{
    float A[3][6], impar=0, col=0;

    for(int i=0; i<3; i++){
        for(int j=0; j<6; j++){
            printf("Digite [%d,%d] valor de A: ", i, j);
            scanf("%f", &A[i][j]);
            if(j%2==0) impar += A[i][j];
            if(j==1 || j==3) col += A[i][j];
        }
    }
    printf("Matriz\n");
    for(int i=0; i<3; i++){
        for(int j=0; j<6; j++){
            printf("%5.1f ", A[i][j]);
        } 
        printf("\n");
    }
    printf("Matriz Modificada\n");
    for(int i=0; i<3; i++){
        for(int j=0; j<6; j++){
            if(j==5) A[i][j] = A[i][0] + A[i][1];
            printf("%5.1f ", A[i][j]);
        } 
        printf("\n");
    }
    printf("\nSoma dos elementos das colunas impares: %.1f\n", impar);
    printf("Media aritmetica da segunda e quarta coluna: %.1f", col/6.0);

    return 0;
}