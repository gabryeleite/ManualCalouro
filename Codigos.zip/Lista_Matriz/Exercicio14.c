#include <stdio.h>

int main()
{
    int A[4][3][3];

    for(int i=0; i<4; i++){
        for(int j=0; j<3; j++){
            for(int k=0; k<3; k++){
                A[i][j][k] = i + j + k;
            }
        }
    }
    printf("Matriz\n");
    for(int i=0; i<4; i++){
        for(int j=0; j<3; j++){
            for(int k=0; k<3; k++){
                printf("A[%d][%d][%d] = %d\n", i, j, k, A[i][j][k]);
            }
        }
    }

    return 0;
}