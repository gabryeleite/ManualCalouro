#include <stdio.h>

int main()
{
    int A[3][3], soma = 0;

    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            printf("Digite [%d,%d]: ", i, j);
            scanf("%d", &A[i][j]);
        }
    }
    
    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            printf("%3d", A[i][j]);
        }
        printf("\n");
    }
    int j = 2;
    for(int i=0; i<3; i++){
        soma += A[i][j];
        j--;
    }

    printf("Soma da diagonal secundaria: %d\n", soma);

    return 0;
}