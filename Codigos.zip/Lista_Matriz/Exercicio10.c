#include <stdio.h>

int main()
{
    char A[5][10], V[10], R[10], soma = 0;

    printf("GABARITO\n");
    for(int i=0; i<10; i++){
        printf("Digite a %d.o resposta: ", i+1);
        scanf(" %c", &V[i]);
    }
    for(int i=0; i<5; i++){
        printf("ALUNO %d\n", i+1);
        for(int j=0; j<10; j++){
            printf("Digite %d.o resposta: ", j+1);
            scanf(" %c", &A[i][j]);
            if(A[i][j]==V[j]) soma++;
        }
        R[i] = soma;
        soma = 0;
    }
    printf("\nRespostas Alunos\n");
    for(int i=0; i<5; i++){
        for(int j=0; j<10; j++){
            printf("%3c", A[i][j]);
        }
        printf("\n");
    }
    printf("GABARITO\n");
    for(int i=0; i<10; i++){
        printf("%3c", V[i]);
    }
    printf("\n\nNOTAS:\n");
    for(int i=0; i<5; i++){
        printf("ALUNO %d: %d\n", i+1, R[i]);
    }

    return 0;
}