#include <stdio.h>
#include <stdlib.h>
#define N 3

void PrintMatriz(char A[][N]);
int Velha(char A[][N]);

int main()
{
    char A[][N] = {"---", "---", "---"};
    int x, y, velha = 0, cont = 0;

    printf("JOGO DA VELHA\n");

    while(cont<9){
    printf("\nJOGADOR 1\nEscolha a posicao [x,y]: ");
    scanf("%d%d", &x, &y);
    while(A[x][y]!='-'){
        printf("Espaco ja ocupado!\nPor favor digite outro[x,y]: ");
        scanf("%d%d", &x, &y);
    }
    A[x][y] = 'X';
    cont++;
    system("cls");
    PrintMatriz(A);
    velha = Velha(A);
    if(velha==1){
        printf("\nJogador 1 ganhou!\n");
        break; 
    } 

    if(cont>=8) break;

    printf("\nJOGADOR 2\nEscolha a posicao [x,y]: ");
    scanf("%d%d", &x, &y);
    while(A[x][y]!='-'){
        printf("Espaco ja ocupado!\nPor favor digite outro[x,y]: ");
        scanf("%d%d", &x, &y);
    }
    A[x][y] = 'O';
    cont++;
    system("cls");
    PrintMatriz(A);
    velha = Velha(A);
    if(velha==1){
        printf("\nJogador 2 ganhou!\n");
        break; 
    } 
    }
    if(velha!=1) printf("\nDeu velha!\n");

    return 0;
}
void PrintMatriz(char A[][N])
{
    printf("JOGO DA VELHA\n\n");
    for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            printf("%3c", A[i][j]);
        }
        printf("\n");
    }
}
int Velha(char A[][N])
{
    if(A[0][0]==A[1][1] && A[1][1]==A[2][2] && A[0][0]!='-') return 1;
    else if(A[0][2]==A[1][1] && A[1][1]==A[2][0] && A[0][2]!='-') return 1;
    else{
        for(int i=0; i<N; i++){
            if(A[i][0]==A[i][1] && A[i][1]==A[i][2] && A[i][0]!='-') return 1;
            else if(A[0][i]==A[1][i] && A[1][i]==A[2][i] && A[0][i]!='-') return 1;
        }
    }
    return 0;
}