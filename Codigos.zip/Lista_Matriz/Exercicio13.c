#include <stdio.h>

int main()
{
    int A[3][3], teste = 0, contiguo;

    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            printf("Digite [%d,%d] valor de A: ", i, j);
            scanf("%d", &A[i][j]);
        }
    }
    printf("Matriz\n");
    for(int i=0; i<3; i++){
        for(int j=0; j<3; j++){
            printf("%3d", A[i][j]);
            if(A[i][j]==A[i][j+1] || A[i][j]==A[i+1][j]){
                if(teste==0) contiguo = A[i][j];
                teste++;
                if(teste==2 && A[i][j]==contiguo) teste--;
            } 
        } 
        printf("\n");
    }
    if(teste>=2) printf("Ha pelo menos 2 elementos contiguos\n");
    else printf("NAO ha pelo menos 2 elementos contiguos\n");

    return 0;
}