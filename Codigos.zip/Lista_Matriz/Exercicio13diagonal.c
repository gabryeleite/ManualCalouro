#include <stdio.h>

int main()
{
    int A[7][8];
    int teste = 0, contiguo;
    //Completando matriz com 0 para a comparacao ser feita com um valor(0) em vez de "lixo".
    for(int i=0; i<7; i++){
        for(int j=0; j<8; j++) A[i][j] = 0;
    }
    printf("Por favor digite valores diferentes de 0!\n");
    for(int i=1; i<6; i++){
        for(int j=1; j<7; j++){
            printf("Digite [%d,%d] valor de A: ", i-1, j-1);
            scanf("%d", &A[i][j]);
        }
    }

    printf("Matriz\n");
    for(int i=1; i<6; i++){
        for(int j=1; j<7; j++){
            printf("%3d ", A[i][j]);
            if(A[i][j]==A[i][j+1] || A[i][j]==A[i+1][j] || A[i][j]==A[i-1][j+1] || A[i][j]==A[i+1][j+1]){
                if(teste==0) contiguo = A[i][j];
                teste++;
                if(teste==2 && A[i][j]==contiguo) teste--;
            } 
        } 
        printf("\n");
    }

    printf("Matriz com 0 (apenas para visualizacao)\n");
    for(int i=0; i<7; i++){
        for(int j=0; j<8; j++) printf("%3d ", A[i][j]);
        printf("\n");
    }

    if(teste>=2) printf("Ha pelo menos 2 elementos contiguos\n");
    else printf("NAO ha pelo menos 2 elementos contiguos\n");

    return 0;
}