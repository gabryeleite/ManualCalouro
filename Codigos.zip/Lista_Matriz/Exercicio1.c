#include <stdio.h>

int main()
{
    int A[7][7], B[7][7], C[7][7];

    for(int i=0; i<7; i++){
        for(int j=0; j<7; j++){
            printf("Digite [%d,%d] valor de A: ", i, j);
            scanf("%d", &A[i][j]);
            printf("Digite [%d,%d] valor de B: ", i, j);
            scanf("%d", &B[i][j]);
        }
    }
    printf("Matriz A\n");
    for(int i=0; i<7; i++){
        for(int j=0; j<7; j++) printf("%3d", A[i][j]);
        printf("\n");
    }
    printf("Matriz B\n");
    for(int i=0; i<7; i++){
        for(int j=0; j<7; j++) printf("%3d", B[i][j]);
        printf("\n");
    }

    for(int i=0; i<7; i++){
        for(int j=0; j<7; j++){
            C[i][j] = 0;
            for(int k=0; k<7; k++){
                C[i][j] += A[i][k]*B[k][j];
            }
        } 
    }
    printf("Matriz Multipicada\n");
    for(int i=0; i<7; i++){
        for(int j=0; j<7; j++) printf("%3d", C[i][j]);
        printf("\n");
    }

    return 0;
}