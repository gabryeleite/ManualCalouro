#include <stdio.h>

int main()
{
    int linA, colA, linB, colB;

    do{
    printf("Digite numero de linhas e colunas de A: ");
    scanf("%d%d", &linA, &colA);
    printf("Digite numero de linhas e colunas de B: ");
    scanf("%d%d", &linB, &colB);
    if(colA!=linB) printf("Numero de colunas de A precisam ser iguais as linhas de B!\n");
    }while(colA!=linB);

    int A[linA][colA], B[linB][colB], C[linA][colB];

    printf("Matriz A\n");
    for(int i=0; i<linA; i++){
        for(int j=0; j<colA; j++){
            printf("Digite [%d,%d]: ", i, j);
            scanf("%d", &A[i][j]);
        }
    }
    printf("Matriz B\n");
    for(int i=0; i<linB; i++){
        for(int j=0; j<colB; j++){
            printf("Digite [%d,%d]: ", i, j);
            scanf("%d", &B[i][j]);
        }
    }

    printf("Matriz A\n");
    for(int i=0; i<linA; i++){
        for(int j=0; j<colA; j++) printf("%3d", A[i][j]);
        printf("\n");
    }
    printf("Matriz B\n");
    for(int i=0; i<linB; i++){
        for(int j=0; j<colB; j++) printf("%3d", B[i][j]);
        printf("\n");
    }

    for(int i=0; i<linA; i++){
        for(int j=0; j<colB; j++){
            C[i][j] = 0;
            for(int k=0; k<linB; k++){
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }

    printf("Matriz Resultante\n");
    for(int i=0; i<linA; i++){
        for(int j=0; j<colB; j++) printf("%3d ", C[i][j]);
        printf("\n");
    }

    return 0;
}