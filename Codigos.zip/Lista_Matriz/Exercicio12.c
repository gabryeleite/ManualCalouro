#include <stdio.h>

int main()
{
    int A[5][5], B[5][5], teste = 0;

    for(int i=0; i<5; i++){
        for(int j=0; j<5; j++){
            printf("Digite [%d,%d] valor de A: ", i, j);
            scanf("%d", &A[i][j]);
            printf("Digite [%d,%d] valor de B: ", i, j);
            scanf("%d", &B[i][j]);
            if(A[i][j]!=B[i][j]) teste++;
        }
    }
    printf("Matriz A\n");
    for(int i=0; i<5; i++){
        for(int j=0; j<5; j++) printf("%3d", A[i][j]);
        printf("\n");
    }
    printf("Matriz B\n");
    for(int i=0; i<5; i++){
        for(int j=0; j<5; j++) printf("%3d", B[i][j]);
        printf("\n");
    }
    if(teste==0) printf("As matrizes sao iguais\n");
    else printf("As matrizes NAO sao iguais\n");

    return 0;
}