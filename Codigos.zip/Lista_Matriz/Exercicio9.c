#include <stdio.h>

int main()
{
    int A[4][4];

    for(int i=0; i<4; i++){
        for(int j=0; j<4; j++){
            printf("Digite [%d,%d]: ", i, j);
            scanf("%d", &A[i][j]);
        }
    }
    printf("Matriz\n");
    for(int i=0; i<4; i++){
        for(int j=0; j<4; j++){
            printf("%3d", A[i][j]);
        }
        printf("\n");
    }
    printf("Matriz Transposta\n");
    for(int i=0; i<4; i++){
        for(int j=0; j<4; j++){
            printf("%3d", A[j][i]);
        }
        printf("\n");
    }

    return 0;
}